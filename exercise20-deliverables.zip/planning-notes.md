# Planning Notes — Bookmark Manager API

## Task list (8 chunks, as actually built)

1. Scaffold + vitest/supertest test tooling + centralized error-handling middleware + `GET /health`
2. Data layer: `Bookmark` type, in-memory store, ID strategy (`crypto.randomUUID()`)
3. `POST /bookmarks` — validation rules decided and documented up front
4. `GET /bookmarks` (list + `?tag=` filter)
5. `GET /bookmarks/:id`
6. `PATCH /bookmarks/:id` — partial-update semantics decided up front
7. `DELETE /bookmarks/:id`
8. Env-based config (`PORT`) + `.env.example`

This is a revision of my original plan, made after a fresh-context planning review (see
below) — health check moved from its own late chunk into chunk 1, and chunk 3 was
explicitly scoped to include writing down the validation rules (not just "add
validation"), per that review's feedback.

## Definition of done per chunk

1. `npm install` succeeds, `npx tsc --noEmit` zero errors, server boots, `curl /health`
   returns `{"status":"ok"}`
2. Storage module imports cleanly; a throwaway script creates → retrieves → confirms a match
3–7. (per endpoint) test suite passes (happy + error case), curl with valid input matches
   expected shape, curl with bad input returns 400/404 with a message instead of crashing
8. `curl /health` still works; server honors `PORT`; `.env.example` documents every variable

## Production checklist (3 items held to every chunk)

Input validation on every endpoint, proper error handling with correct HTTP status codes
(not a crash, not a bare 500), and at least one happy-path + one error-case test per
endpoint.

## Step 1 — planning review (before any code)

Shared the original 8-chunk plan with a fresh `Plan`-type agent and asked it to review
ordering, sizing, and gaps — no code written yet. It found one real ordering gap (test
tooling was never its own setup step), correctly flagged chunk 3 (POST) as
underspecified (validation rules, ID strategy, duplicate-URL policy were all undecided),
flagged a hidden design decision in chunk 6 (PATCH partial-update semantics), and caught
that there was no chunk for centralized error-handling middleware even though the
production checklist implies one. It also suggested merging the list and get-by-id
chunks to rebalance sizing.

**My call:** adopted nearly everything (test tooling into chunk 1, explicit validation
rules documented in chunk 3, explicit partial-update semantics in chunk 6, centralized
error middleware moved into chunk 1, health check moved into chunk 1). I explicitly
rejected merging list and get-by-id into one chunk — the exercise's whole point is the
one-endpoint-at-a-time build-verify-commit discipline, and collapsing two endpoints into
one commit to save a chunk would undermine exactly what's being practiced.

## Honest notes on what actually happened after planning

The planning review was good but not complete — a few real problems weren't caught until
later, by actually running things:
- While writing chunk 4's tests, discovered the in-memory repository is a module-level
  singleton with no reset between tests, causing real cross-test state leakage (caught
  by a failing assertion, not by review).
- `vitest` inherited the monorepo root's `vitest.config.ts` (which references
  `client`/`server` project configs) since `bookmark-api` had none of its own — caught by
  actually running `npx vitest run` in chunk 1, not by planning.
- The Step 6 final review (a fresh `pr-reviewer` subagent that sent real HTTP requests to
  the running server, not just read the code) found four real, confirmed bugs that had
  shipped across earlier "verified" chunks: `javascript:` URLs were accepted and stored
  (a stored-XSS vector), a missing/non-JSON body crashed POST/PATCH with a 500, PATCH
  didn't type-check fields the way POST did (a non-string title also crashed with 500,
  and an array `url` silently passed through `new URL()`'s coercion), and `description`
  was never validated at all. All were fixed in a final commit — see `build-evidence.txt`.
