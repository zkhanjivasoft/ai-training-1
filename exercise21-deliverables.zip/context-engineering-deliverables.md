# Context Engineering in Practice — Deliverables

Task: implement `POST /notes` (create) for `notes-api`, a real, currently-unimplemented
feature in this repo (chosen instead of the exercise's suggested task-management-API
template, to get genuine context dynamics rather than repeating a near-identical build
from an earlier exercise). Full session trace in `context-log.txt`.

## 1. Context management prompts (5 — exceeds the minimum of 4)

1. **"We're implementing POST /notes in notes-api/ on main. Anchor facts for this whole
   session: (1) notes-api is a SEPARATE project from the TaskBoard server... (2) main
   currently only has GET /notes and GET /notes/:id — there is NO create endpoint, NO
   error-handling middleware, and NO HttpError class on main right now, regardless of
   what existed on any other branch before. (3) Don't touch server/ or client/ at all
   this session."**
   *Strategy: establishing context anchors at session start. Proactive — anticipated
   that my own memory of a similar-looking setup on an abandoned branch could bleed into
   this session before any signal of it actually appeared.*

2. **"Before writing anything, grep notes-api/src for 'HttpError' and 'errorHandler',
   and ls src/middleware and src/lib... don't read the whole file tree yet."**
   *Strategy: targeted search instead of loading entire files. Proactive — verifying the
   anchor against reality rather than trusting it outright.*

3. **"Read exactly these three files, nothing else: notes.routes.ts, notes.service.ts,
   types.ts."**
   *Strategy: loading only specifically needed files. Proactive — scoped to exactly what
   the next design decision required, not the whole project.*

4. **"Before writing tests: summarize what's been built so far in 2-3 sentences, and
   confirm the plan for the test phase, before touching any test file."**
   *Strategy: summarizing progress before continuing to a new phase. Proactive — used
   deliberately to also double-check I wasn't about to repeat a specific known bug
   (the cross-test state-leakage issue from an earlier exercise) before starting to
   write tests.*

5. **"Updating README's API surface table now. Do NOT also fix notesService.list()
   being dead code in this session — just update the docs for POST and move on."**
   *Strategy: context hierarchy exclusion (see section 3 below for the full reasoning).
   Proactive — a scope decision made before drifting into an adjacent cleanup.*

## 2. Two prompts where staleness was spotted

1. **"Plan the implementation: add create() to the service, a POST route, and
   validation."**
   *Signal observed: my own first-draft plan assumed the HttpError/errorHandler pair
   from a since-abandoned branch (several exercises back in this project's history) was
   still live on `main`, and proposed reusing it — directly contradicting what a grep two
   exchanges earlier had just confirmed didn't exist. This is the "references code or
   decisions from earlier that have since changed" signal type, where the "earlier" in
   question was from well before this session (deep project history), not from within
   the session itself.*

2. **"Before documenting this, re-check: does the POST route actually match GET /:id's
   error-handling pattern, like I claimed earlier?"**
   *Signal observed: re-reading my own implementation against my own earlier stated
   justification ("matches the existing GET /:id pattern exactly") showed they didn't
   match at all — GET /:id uses a plain inline undefined-check with no exception; POST
   uses throw + try/catch. The claim and the code had been inconsistent since the moment
   I wrote the code, and I didn't notice until deliberately re-checking several exchanges
   later. This is the "produces output that contradicts an earlier correction/decision"
   signal type.*

## 3. One prompt where context was deliberately excluded

**"Updating README's API surface table now. Do NOT also fix notesService.list() being
dead code in this session — just update the docs for POST and move on."**

*Excluded: fixing `notesService.list()` being unreachable dead code (the route calls
`search()` unconditionally, a leftover from an earlier exercise). Why it falls below
"Important": it has zero effect on shipping `create` — no behavior depends on it, no test
exercises it, and no user-facing path reaches it. It's a legitimate but independent
cleanup with no dependency relationship to this session's actual goal, making it
"Useful" at best (worth doing, not worth doing *now*, and not worth loading
`notes.service.ts` back into active working context with a refactoring mindset while I
was mid-way through a feature-add).*

## 4. One-sentence reflection

I would set the anchor to explicitly name the abandoned branch by reference (not just
describe its absence) — "a similar HttpError/errorHandler setup exists on the old
`feat/notes-create` branch, not on `main`" — since the staleness I actually hit came from
*recalling* that prior design, not from anything in the current files, and naming the
source of the stale memory up front would likely have prevented the slip in exchange #4
rather than requiring a correction after the fact.
