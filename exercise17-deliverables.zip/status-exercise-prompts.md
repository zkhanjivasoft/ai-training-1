# Status Exercise — Prompts

## Initial prompt

> Write a Node.js script called status.js that prints a status report to the terminal
> when run with `node status.js`.
>
> The output should look exactly like this:
> Status: OK
> Time: 2024-01-15T10:30:00.000Z
>
> Requirements:
> - Use console.log to print each line
> - Get the current time using `new Date().toISOString()`
> - No npm packages — only built-in Node.js features

**Result:** worked on the first try. Ran `node status.js` and got:
```
Status: OK
Time: 2026-09-30T15:32:45.751Z
```
No adjustment needed — the requirements list (console.log, `toISOString()`, no packages)
left no ambiguity.

## Iteration prompt

> Now add a third line to the output that shows how long Node has been running, using
> process.uptime(). Round it to 2 decimal places. The new line should look like:
>
> Uptime: 0.05s

**Result:** also worked on the first try. This prompt only describes the *new* line and
relies on the existing conversation/file for everything else (it doesn't re-specify the
`Status: OK` or `Time:` lines at all), and ran cleanly:
```
Status: OK
Time: 2026-09-30T15:32:52.637Z
Uptime: 0.02s
```

## (Stretch) Freeform prompt

> Add a fourth line to status.js that shows current memory usage using
> `process.memoryUsage().heapUsed`. That value comes back in bytes, so convert it to
> megabytes, round to 2 decimal places, and label the line "Memory:" followed by the
> number and "MB" — e.g. `Memory: 4.21 MB`.

**Result:** worked on the first try. Ran and got:
```
Status: OK
Time: 2026-09-30T15:33:00.252Z
Uptime: 0.02s
Memory: 3.81 MB
```
No template was given for this one in the instructions, so I had to specify the
byte-to-MB conversion explicitly myself (the exercise's own hint only named the source
value and rounding, not the unit conversion) — that was the one detail I made sure not to
leave implicit, since `heapUsed` alone is in bytes, not MB.
