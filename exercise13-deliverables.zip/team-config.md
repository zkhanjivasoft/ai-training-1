# Team Configuration

## Note on /memory verification

`/memory` is an interactive Claude Code slash-command with no tool-call equivalent I can
invoke on myself in this session, so I can't paste a literal captured `/memory` output.
What I can show instead is real evidence from this actual session that both files are
genuinely loaded, which is what `/memory` would confirm:
- The root `CLAUDE.md` (and its `@AGENTS.md` import) has been re-injected verbatim as a
  system-reminder mid-conversation, labeled "project instructions, checked into the
  codebase" — proof it's read from disk into context, not just something I was told once.
- `.claude/settings.json`'s hooks have observably fired throughout this session: every
  `Edit`/`Write` in this conversation triggered a `PostToolUse:Edit` note referencing
  `check-convention.js`, and the seed.json deny rule plus `protect-seed.js` are documented
  in `CLAUDE.md` itself as actively enforced.

If a literal `/memory` capture is required for grading, run `/memory` in an interactive
session and it should list both `CLAUDE.md` and `.claude/settings.json` under loaded
project configuration.

## .claude/settings.json

```json
{
  "permissions": {
    "allow": ["Bash(npm run typecheck:*)", "Bash(npm test:*)"],
    "deny": [
      "Edit(server/data/seed.json)",
      "Write(server/data/seed.json)",
      "Bash(git push --force:*)",
      "Bash(rm -rf:*)"
    ]
  },
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          { "type": "command", "command": "node \"$CLAUDE_PROJECT_DIR/.claude/hooks/protect-seed.js\"" },
          { "type": "command", "command": "node \"$CLAUDE_PROJECT_DIR/.claude/hooks/check-convention.js\"" }
        ]
      }
    ],
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          { "type": "command", "command": "node \"$CLAUDE_PROJECT_DIR/.claude/hooks/check-convention.js\"" }
        ]
      }
    ]
  }
}
```

Covers all three required rule shapes:
- **Allow, safe/frequent:** `Bash(npm run typecheck:*)`, `Bash(npm test:*)` — read-only,
  side-effect-free, run constantly during any change.
- **Deny:** `Edit`/`Write` on `server/data/seed.json` (the canonical reset baseline every
  lab depends on).
- **Tool-specific pattern:** every rule here is scoped to an exact tool + command prefix
  (`Bash(git push --force:*)`, `Bash(rm -rf:*)`) rather than a blanket allow/deny on the
  whole `Bash` tool — Bash is only ever permitted for the specific command shapes listed.

## CLAUDE.md (root)

```markdown
# Project — TaskBoard

Task-board training app: React client + Express API + JSON-file database.
npm-workspaces monorepo: `client/`, `server/`, `shared/`.

## Stack & overview

- Language / runtime: TypeScript (strict) on Node ≥ 20
- Frameworks: React 18 + Vite (client), Express 5 (server), Vitest + zod
- Database: JSON file (`server/data/db.json`) behind a repository layer, seeded from the guarded `server/data/seed.json`
- Shared domain/API types: `@taskboard/shared`, imported as TS source (no build step) — never redeclare them locally

## Commands

- First-time setup: `npm install` then `npm run reset-db`
- Run: `npm run dev` — client (5173) + server (3001) together
- Test: `npm test`; one workspace: `npm test -w server`; one file: `npx vitest run src/services/tags.service.test.ts` from inside that workspace
- Lint: `npm run lint` · Typecheck: `npm run typecheck`
- Reset data: `npm run reset-db` — restores `db.json` from the seed

## Code conventions

- Error handling: throw the typed classes from `server/src/lib/errors.ts` for expected failures; produce responses ONLY with `server/src/lib/respond.ts` — every response uses the `{ data, meta? }` / `{ error: { code, message, details? } }` envelope (see docs/adr/0001)
- Naming / structure: named exports only; one component per file, named after it; feature folders follow Page → Grid → Card (+ Form), e.g. `TagsPage`/`TagGrid`/`TagCard`/`TagForm`; styling is co-located CSS Modules using the design tokens in `client/src/index.css` (no raw hex in component CSS); data hooks return `{ <items>, loading, error, refetch, ...mutators }` — copy the shape of `useTags`
- Logging: `logger.info('<file-basename>', message, meta?)` from `server/src/lib/logger.ts`; bare `console.*` in `server/src` fails lint

## Architecture & key dirs

Request flow: route → service → repository → store. Routes parse input (zod) and respond; services own ALL business rules and throw typed errors; repositories only persist.

- `server/src/routes/` — thin HTTP layer: validate, call service, respond
- `server/src/services/` — business rules; the only layer that records activity
- `server/src/repositories/` — persistence; the ONLY layer allowed to import `server/src/db/store.ts`
- `server/data/` — `seed.json` (canonical, guarded) and generated `db.json`
- `client/src/api/` + `client/src/hooks/` — one module and one hook per resource
- `client/src/components/` — feature folders + shared `ui/` primitives
- `shared/src/` — entities, envelope, and query types used by both tiers
- `docs/` — decisions (`adr/`), cross-cutting rules (`nfr/`), recipes (`best-practices/`)

## Testing approach

- Vitest, co-located with the module under test (`x.service.ts` → `x.service.test.ts`)
- Server tests MUST create their data dir via `makeTestDb()` from `server/src/testing/helpers.ts` — never read or assert against the real seed data
- Cover the error paths (404/409/validation) for any endpoint you touch — `tags.routes.test.ts` is the pattern
- Run `npm test`, `npm run lint`, and `npm run typecheck` before every PR

## Deployment

- No hosted deployment: CI (GitHub Actions) runs lint + typecheck + tests on every PR and push to main, and must be green
- Branches `feat/<slug>` / `fix/<slug>`; Conventional Commits; PRs link their issue with `Closes #N`
- Gotchas: Express 5 auto-forwards rejected async handlers to the error middleware — do not add try/catch or wrappers in routes; the client proxies `/api` → :3001, so client API paths are origin-relative; `db.json` is gitignored and generated (a missing db.json is not a bug); `/api/inspiration` simulates a flaky third-party API — its 404/429/500 responses are intended behavior

## Do / Don't

- Do: record architectural decisions in `docs/adr/` (template provided); put cross-cutting rules in `docs/nfr/` (copy the form of NFR-0001); team recipes live in `docs/best-practices/`
- Do: reuse the tags vertical slice as the reference implementation when adding a resource
- Don't: NEVER modify `server/data/seed.json` — it is the canonical baseline every lab resets to (also enforced by a deny rule and a PreToolUse hook); change data via the API or `db.json`, then `npm run reset-db`; done means seed.json has no diff
- Don't: access `db.json` outside `server/src/repositories/` — routes and services never import `db/store.ts`
- Don't: never commit secrets — this repo needs no credentials; anything resembling one is a mistake

## Guardrails

- **Never force-push to `main`** (enforced by a deny rule in `.claude/settings.json`:
  `Bash(git push --force:*)`). Reasoning: `main` is the shared branch every exercise and CI
  build depends on; a force-push can silently discard commits someone else already pushed,
  with no easy recovery once it's overwritten on the remote.
- **Never run `rm -rf`** (enforced by a deny rule in `.claude/settings.json`:
  `Bash(rm -rf:*)`). Reasoning: it's an unrecoverable bulk delete. A narrower, reversible
  action — `git checkout --` to discard tracked changes, `git clean -n` to preview untracked
  files before removing them, or simply moving a file aside — achieves the same cleanup
  without the risk of deleting something that was never meant to go.
- **Never modify `server/data/seed.json`** (see Do/Don't above; also enforced by a deny
  rule and a PreToolUse hook). Reasoning: it's the canonical baseline every lab resets to
  via `npm run reset-db` — a bad edit here corrupts every exercise's starting state, not
  just the current session's.

@AGENTS.md
```

This file already satisfies Task 1's CLAUDE.md requirements (build/test commands, ≥2
project-specific code conventions, an architecture summary, and a gotcha/constraint
section) — it predates this exercise, having been built up across two earlier exercises
in this same project.
