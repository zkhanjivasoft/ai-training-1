# notes-api

REST API for creating and listing plain-text notes. Node >= 20, TypeScript
(strict), Express 5. In-memory store — no database yet.

## Commands

Run from inside `notes-api/`:

- `npm install` — install dependencies
- `npm run dev` — dev server with live reload (`tsx watch`)
- `npm run build` — compile to `dist/` with `tsc`
- `npm start` — run the compiled server (`node dist/index.js`)
- `npm run typecheck` — type-check only, no emit
- No `lint` or `test` script exists yet — don't invent one without asking.

## Code style

- Named exports only. Each layer (route/service/repository) is a single
  object literal with method shorthand, e.g. `export const notesService = {
  list() { ... } }` — no classes, no default exports.
- Relative imports need explicit `.js` extensions (`'./app.js'`, not
  `'./app'`) even though the source is `.ts` — `tsconfig.json` sets
  `moduleResolution: NodeNext`. Omitting the extension fails `tsc` outright
  (`TS2835`), it's not just a runtime issue.
- All service/repository methods are synchronous, no `async`/`await` — the
  store is a plain in-memory array, not I/O. Don't add `async` unless a
  method actually awaits something.

## Project structure

- `src/app.ts` — builds the Express app (`createApp()`), never listens
- `src/index.ts` — the only file that calls `app.listen`
- `src/routes/`, `src/services/`, `src/repositories/` — one file per layer
  per resource, named `<resource>.<layer>.ts`
- `src/types.ts` — the shared `Note` interface

## Gotcha

Notes live in a module-level in-memory array with no persistence — every
restart (including a `tsx watch` reload) wipes all data. Don't write a test
or a demo that assumes a note survives a server restart.
