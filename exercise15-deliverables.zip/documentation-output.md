# Documentation Output — todosService API Reference

## Problems identified in the first draft, and the correction prompt

**Problem 1 — `meta.total` was documented as the total matching count across all pages.**
The v1 draft said: *"`meta.total` is the total number of todos matching the applied
filters... use `meta.total` together with `meta.pageSize` to compute how many pages
exist."* Re-reading `todos.service.ts:54-59` shows `meta: { total: pageItems.length, ... }`
— `total` is actually just `pageItems.length`, the count of items on the *current page*.
On any page that isn't a full, final page, this number is smaller than the true matching
count, and it can never be used to derive how many pages exist the way the draft claimed.

**Problem 2 — `update()`'s notes-clearing behavior was stated backwards.** The v1 draft
said: *"to remove a todo's notes, simply omit `notes` from the input and it will be
cleared."* Re-reading `todos.service.ts:93-100` shows
`...(input.notes !== undefined && { notes: input.notes ?? undefined })` — omitting
`notes` means `input.notes !== undefined` is `false`, so the spread contributes nothing
and the field is left completely untouched. The only way to actually clear `notes` is to
explicitly send `notes: null`.

**Follow-up prompt sent:**
> "Two corrections needed in the `todosService` doc, both from re-reading the actual
> source instead of assuming standard pagination/PATCH semantics:
> 1. `meta.total` in `list()` is `pageItems.length` (line 58) — the count on the *current
>    page*, not the total matching count. Remove the claim that you can compute total
>    pages from `meta.total`/`meta.pageSize`; state plainly what it actually is.
> 2. `update()`'s notes-clearing is backwards in the draft. Per line 94
>    (`...(input.notes !== undefined && { notes: input.notes ?? undefined })`), *omitting*
>    `notes` leaves it unchanged; you must explicitly pass `notes: null` to clear it. Fix
>    the wording and add the same note for `dueDate`, which uses the identical pattern
>    (line 98)."

---

## Final revised documentation

# todosService — API Reference

`server/src/services/todos.service.ts` is the business-rules layer for todos: it owns
validation, id/timestamp generation, activity recording, and is the only thing routes
call for todo operations.

## `list(query)`

Returns a paginated, filtered, sorted list of todos.

- Filters (all optional): `status`, `priority`, `listId`, `tagId`, and `q` (free-text
  search over title and notes).
- Always sorted by `createdAt`, newest first.
- Paginates using `page`/`pageSize`.
- Returns `{ todos, meta }`. **`meta.total` is the number of items on the current
  returned page (`pageItems.length`), not the total count of all todos matching the
  filters** — it cannot be used to compute the total number of pages. `meta.page` and
  `meta.pageSize` echo the requested page/pageSize back.

## `getById(id)`

Returns the todo, or throws `NotFoundError` if it doesn't exist.

## `create(input)`

Validates that `listId` and every id in `tagIds` reference real records, then creates the
todo with status `'open'`, a generated id, and `createdAt`/`updatedAt` timestamps. Records
a `'created'` activity entry.

## `update(id, input)`

Applies a partial update. Every field is optional — pass only the fields you want to
change; anything you omit entirely is left as-is. **For the nullable fields `notes` and
`dueDate`, omitting the key and explicitly sending `null` are different**: omitting the
key leaves the current value untouched, while explicitly sending `notes: null` (or
`dueDate: null`) clears it. Re-validates any new `listId`/`tagIds` references. Records an
`'updated'` activity entry.

## `complete(id)` / `reopen(id)`

Transition a todo to `'done'`/`'open'`. `complete` stamps `completedAt`; `reopen` clears
it. Both are no-ops if the todo is already in the target state, and both record an
activity entry (`'completed'`/`'reopened'`).

## `remove(id)`

Deletes the todo and records a `'deleted'` activity entry.
