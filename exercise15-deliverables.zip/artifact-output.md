# Artifact Output — Dockerfile for the server

**Option chosen:** B (Configuration/Infrastructure).

**Plain-English description given:** "Create a Dockerfile for this project's server —
it's an npm-workspaces monorepo (`shared`/`server`/`client`), the server is Node 20 +
Express 5, and it has no build step: it runs TypeScript directly via `tsx` in both dev
and production (`tsx src/index.ts`), consuming `@taskboard/shared` as TS source too. It
listens on port 3001 by default. A GitHub Actions CI workflow already runs lint/typecheck/
tests on every push, so don't duplicate that — just the Dockerfile."

## v1 (first draft) and the problem found on review

```dockerfile
FROM node:20-alpine

WORKDIR /app

COPY package.json package-lock.json ./
COPY shared/package.json shared/package.json
COPY server/package.json server/package.json

RUN npm ci --omit=dev

COPY shared ./shared
COPY server ./server

EXPOSE 3001
CMD ["npm", "run", "start", "-w", "server"]
```

**Problem found on review:** `npm ci --omit=dev` looks like standard "production image"
practice, but it's wrong for this specific stack. `server/package.json:23` lists `tsx`
under `devDependencies`, and the server's own `start` script is `tsx src/index.ts` — per
this repo's own documented convention (`BE-066`: "The server has no build step: it runs
TypeScript sources directly via `tsx`... Never add a bundler/`tsc` emit"), `tsx` isn't a
dev-only tool here, it's the actual runtime. `--omit=dev` would strip it from the image,
and `CMD ["npm", "run", "start", "-w", "server"]` would fail at container startup with
`tsx: not found` (or an equivalent module-resolution error). (Caveat: I reasoned this
through against the actual `package.json` rather than confirming it with a real
`docker build` — Docker isn't available in this environment to execute one.)

**Refinement prompt sent:**
> "`--omit=dev` will break this: `tsx` is a devDependency but it's actually the runtime
> for this server, since the project deliberately has no build step (see `BE-066` in
> `.claude/rules/backend.md`). Don't try to add a `tsc` build stage either — that would
> go against the documented convention. Just install all dependencies (drop
> `--omit=dev`) so `tsx` is present at runtime, and add a non-root user while you're at
> it since the original draft ran as root."

## v2 (final, refined)

```dockerfile
FROM node:20-alpine

WORKDIR /app

COPY package.json package-lock.json ./
COPY shared/package.json shared/package.json
COPY server/package.json server/package.json

# No --omit=dev: this project has no build step (BE-066) — tsx (a devDependency)
# is the actual runtime for the server, not a dev-only tool.
RUN npm ci

COPY shared ./shared
COPY server ./server

RUN addgroup -S app && adduser -S app -G app
USER app

EXPOSE 3001
CMD ["npm", "run", "start", "-w", "server"]
```

Change from v1 to v2: dropped `--omit=dev` (the substantive fix — the image now actually
boots), and added a non-root `app` user before the final `CMD` (the additional refinement
requested in the same follow-up prompt).
