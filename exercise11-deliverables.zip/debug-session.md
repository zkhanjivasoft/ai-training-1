# Debug Session — tags.service.ts sort order

## Setup

Introduced a subtle bug into `server/src/services/tags.service.ts`'s `list()` method —
swapped the comparator arguments in the `.toSorted()` call
(`a.name.localeCompare(b.name)` → `b.name.localeCompare(a.name)`), reversing the sort
from ascending to descending. Confirmed the existing test suite failed as a result:

```
FAIL  |server| src/services/tags.service.test.ts > tagsService > lists tags sorted by name
AssertionError: expected [ 'unused', 'beta', 'alpha' ] to deeply equal [ 'alpha', 'beta', 'unused' ]

- Expected
+ Received

  [
-   "alpha",
-   "beta",
    "unused",
+   "beta",
+   "alpha",
  ]

 ❯ src/services/tags.service.test.ts:19:19
     17|   it('lists tags sorted by name', () => {
     18|     const names = tagsService.list().map((t) => t.name);
     19|     expect(names).toEqual(['alpha', 'beta', 'unused']);
       |                   ^
     20|   });
     21|

 Test Files  1 failed | 9 passed (10)
      Tests  1 failed | 57 passed (58)
```

## Symptom-first bug report (given to a fresh, isolated subagent — not the session that introduced the bug)

> I've got a failing test in the server workspace and I don't know why. Here's what I'm
> seeing:
>
> Running `npx vitest run` from inside `server/` gives me:
>
> ```
> FAIL  |server| src/services/tags.service.test.ts > tagsService > lists tags sorted by name
> AssertionError: expected [ 'unused', 'beta', 'alpha' ] to deeply equal [ 'alpha', 'beta', 'unused' ]
>
> - Expected
> + Received
>
>   [
> -   "alpha",
> -   "beta",
>     "unused",
> +   "beta",
> +   "alpha",
>   ]
>
>  ❯ src/services/tags.service.test.ts:19:19
>      17|   it('lists tags sorted by name', () => {
>      18|     const names = tagsService.list().map((t) => t.name);
>      19|     expect(names).toEqual(['alpha', 'beta', 'unused']);
>        |                   ^
>      20|   });
>      21|
>
>  Test Files  1 failed | 9 passed (10)
>       Tests  1 failed | 57 passed (58)
> ```
>
> I expected the tag list to come back sorted alphabetically by name, same as it always
> has. This just started happening after some recent changes in this area of the
> codebase — I haven't pinned down which change caused it.
>
> Please investigate and find the root cause. Do NOT propose or apply any fix yet —
> first explain, in your own words, exactly what is causing this specific symptom (cite
> the file and line), and why the observed output is what it is given that root cause.
> Wait for me to confirm before making any code changes.

No mention of the exact line, the file being `tags.service.ts`, or that the change was a
swapped comparator — only the symptom, the expected behavior, and the error output.

## Claude's diagnosis (before any fix)

> Root cause found — no fix applied yet.
>
> File: `server/src/services/tags.service.ts`, line 10 (uncommitted local change, per
> `git diff`):
>
> ```ts
> list(): Tag[] {
>   return tagsRepository.findAll().toSorted((a, b) => b.name.localeCompare(a.name));
> },
> ```
>
> The comparator's arguments are reversed. The original/correct code is
> `a.name.localeCompare(b.name)`, which sorts ascending. The current working-tree edit
> swapped it to `b.name.localeCompare(a.name)`, which sorts descending.
>
> Why this produces exactly the observed output: the underlying (unsorted, insertion-order)
> tag data presumably has an order where alphabetical-ascending is
> `['alpha', 'beta', 'unused']`. With the comparator reversed, `toSorted` produces the
> exact reverse of that ascending order: `['unused', 'beta', 'alpha']` — which matches the
> "Received" array in the failing assertion precisely. This is a textbook signature of a
> flipped comparator, not a data problem, a caching problem, or a repository-layer issue:
> `tagsRepository.findAll()` itself isn't sorting, and `list()` is the only place sort
> order is applied.
>
> Confirmed this is uncommitted/local (not from a prior merged commit) via
> `git diff server/src/services/tags.service.ts`, which shows exactly this one-line
> change (`a.name`/`b.name` swapped) against HEAD.
>
> No code changes made. Waiting for confirmation before fixing (the fix would just be
> swapping the comparator back to `a.name.localeCompare(b.name)` on line 10).

## Proposed fix

Swap the comparator back to `a.name.localeCompare(b.name)` (ascending) — a one-line,
minimal, targeted fix addressing exactly the identified root cause, with no other change.

## Test results after the fix

Applied by the same subagent, then verified independently by me as well:

```
 Test Files  10 passed (10)
      Tests  58 passed (58)
   Duration  538ms
```

And, running the full monorepo suite (`npm test` equivalent across workspaces) from the
repo root after the fix:

```
 Test Files  15 passed (15)
      Tests  78 passed (78)
```

`git diff server/src/services/tags.service.ts` after the fix shows no diff — the file is
back to its original, correct state.
