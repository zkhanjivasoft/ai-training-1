# Debug Reflection

**Did Claude find the actual root cause on the first attempt, or did it need guidance?**
On the first attempt, with no follow-up guidance needed. I built "explain root cause
before fixing" directly into the initial prompt rather than needing a second corrective
message, and the diagnosis was exactly right: it correctly named the swapped comparator
and, more importantly, correctly reasoned about *why* that specific change produces that
specific reversed array rather than just noting "a change was made." Worth being honest
about one thing: it partly used `git diff` to locate the change, which is a legitimate
real debugging technique, but is also a bit of a shortcut in this exercise's artificial
setup — the bug was still uncommitted, so the diff was highly visible. If this had been
buried several commits deep in history, I'd expect it to lean more heavily on reasoning
about the sort logic itself (which it also did correctly, independent of the diff) rather
than on `git diff` alone.

**Was the fix minimal and targeted, or did Claude change more than necessary?**
Minimal — exactly the one line that was actually broken, reverting `b.name`/`a.name` back
to `a.name`/`b.name`, with nothing else touched. It didn't refactor the sort, add a
comment, "clean up" the surrounding method, or touch any other file. `git diff` after the
fix showed zero difference from the original, confirming the fix restored exactly the
prior state rather than landing on a different-but-equivalent implementation.

**At what point would I escalate to a subagent or a fresh session?**
Right where I did it here: the moment diagnosis needs to happen without the bias of
already knowing the cause. If I (or the same session that just wrote/changed the code)
try to debug it, I'm not actually testing whether the explanation is sound — I already
know the answer, so I can't tell if the investigation was rigorous or just matched what
I expected to hear. A fresh subagent with only the symptom forces a genuine
investigation. Beyond this specific case, I'd also escalate to a subagent when: the bug
spans multiple files/layers and I want an isolated read-only pass before touching
anything (similar to the fresh-context code review from an earlier exercise); I want a
second opinion on whether a proposed fix actually addresses the root cause versus papering
over the symptom; or the investigation is going to require a lot of exploratory
reading/grepping that would otherwise bloat the main session's context for no lasting
benefit once the root cause is found.
