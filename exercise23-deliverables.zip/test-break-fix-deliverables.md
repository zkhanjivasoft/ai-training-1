# Test, Break, and Fix — Deliverables

**Function:** `truncate(text, maxLength)` in `client/src/lib/text.ts` — word-boundary
string truncation with an ellipsis, used by `ActivityFeed.tsx`. Chosen because it was
genuinely untested, small enough to fully trace by hand, and has real edge cases
(exact-boundary length, no space to break on, trailing whitespace, a space at index 0).

## Test suite + notes on changes from the AI's initial output

Delegated to a fresh agent: first asked it to identify the function's behavior/inputs/
outputs/edge cases/error conditions from the code alone, then to generate 6-8 tests
(Vitest, globals off per this project's convention, co-located `text.test.ts`).

**Its analysis:** correctly identified the no-op/unchanged case, the word-boundary cut,
the no-space fallback, trailing-whitespace handling, `maxLength: 0`, empty-string input,
a leading space sitting at index 0 (correctly noted `lastSpace > 0` excludes index 0, so
a leading space is never stripped), and correctly noted the function never throws
(no runtime validation, relies on TS types).

**The 8 generated tests**, verified by manually tracing the function for each one myself
before trusting them:

```ts
import { describe, it, expect } from 'vitest';
import { truncate } from './text';

describe('truncate', () => {
  it('returns the text unchanged when shorter than maxLength', () => {
    expect(truncate('hello world', 50)).toBe('hello world');
  });
  it('returns the text unchanged when exactly maxLength', () => {
    expect(truncate('hello', 5)).toBe('hello');
  });
  it('truncates at the nearest word boundary and appends an ellipsis', () => {
    expect(truncate('the quick brown fox jumps', 13)).toBe('the quick…');
  });
  it('keeps the whole slice when there is no space to break on', () => {
    expect(truncate('supercalifragilisticexpialidocious', 10)).toBe('supercalif…');
  });
  it('trims trailing whitespace left at the cut point before adding the ellipsis', () => {
    expect(truncate('hello   world', 8)).toBe('hello…');
  });
  it('returns just an ellipsis when maxLength is 0', () => {
    expect(truncate('hello world', 0)).toBe('…');
  });
  it('returns an empty string unchanged', () => {
    expect(truncate('', 10)).toBe('');
  });
  it('does not strip a leading space when the only space is at index 0', () => {
    expect(truncate(' abcdefgh', 5)).toBe(' abcd…');
  });
});
```

**What I changed from the AI's initial output: nothing.** I manually traced every one of
the 8 tests against the function's actual logic before trusting any of them (e.g. for
test 3, hand-computed `"the quick brown fox jumps".slice(0,13)` = `"the quick bro"`,
`lastIndexOf(' ')` = 9, base = `"the quick"` → `"the quick…"`, matching the assertion
exactly) and found every single one correct, non-redundant, and testing a genuinely
distinct code path. I deliberately did *not* remove the "exactly maxLength" test as a
near-duplicate of "shorter than maxLength," since it specifically targets the `<=`
boundary — which turned out to matter directly in Part 2. This is an honest "no
corrections needed" result, not a rubber stamp: I verified rather than assumed.

## Bug description

**What I changed:** `client/src/lib/text.ts` line 3, `if (text.length <= maxLength)
return text;` → `if (text.length < maxLength) return text;` (strict `<` instead of `<=`).

**Why it's realistic:** this is exactly the kind of change a careless refactor or a
"simplify the condition" pass could introduce — the two operators look nearly identical,
compile fine, and don't change behavior for the overwhelming majority of inputs (anything
clearly shorter or clearly longer than `maxLength`). It only breaks the one case where
`text.length` exactly equals `maxLength`, which is precisely why it's a *subtle* bug,
not an obvious one — nothing in a visual diff review highlights `<=` vs `<` as suspicious
without already knowing where to look.

**Effect confirmed by running the suite:** exactly 1 of 8 tests failed (`'returns the
text unchanged when exactly maxLength'`), the other 7 unaffected — meaning the existing
suite already had the coverage to catch this; no test-suite gap was found, so no
gap-filling test was needed (the exercise's optional step only applies if nothing fails).

## AI diagnosis evaluation

**Fully correct, in 1 round.** Given only the raw failing-test output (no hint about what
was changed, no file diff shown), the agent correctly:
- Located the exact line (`text.ts:3`)
- Identified the precise mechanism: at `text.length === maxLength`, the guard is
  skipped, `slice(0, maxLength)` becomes a no-op (returns the same string), `lastIndexOf`
  returns `-1` (no space in a word like `"hello"`), so `base` falls back to the whole
  slice, and the function unconditionally appends `'…'` — producing `'hello…'` instead
  of `'hello'`, matching the exact symptom in the assertion.
- Correctly framed it as a boundary-condition bug, not a logic bug elsewhere.
- Proposed the exact right fix (`<` → `<=`) and proactively verified it wouldn't affect
  the other 7 passing tests, without being asked to check that.
- Correctly stopped and asked before applying the fix, rather than assuming permission.

No extra context was needed beyond the raw test output — no second round, no follow-up
question, no wrong path explored first. This is about as clean a diagnosis as this kind
of exercise can produce, likely because the bug's mechanism is fully determinable from
the function's own ~6 lines without needing any other file's context.

## Regression test + explanation

```ts
// Regression test: the "already fits" guard was once accidentally changed from
// `<=` to `<`, which made a string exactly at maxLength fall through into the
// truncation branch and get a spurious ellipsis appended (e.g. 'world' at
// maxLength 5 became 'world…' instead of staying 'world'), even though nothing
// was actually cut. Covers the same boundary as the "exactly maxLength" test
// above with an independent example, specifically to guard against this defect.
it('regression: does not append an ellipsis when text length exactly equals maxLength', () => {
  expect(truncate('world', 5)).toBe('world');
});
```

**What it targets:** the exact boundary condition that broke (`text.length === maxLength`).
It's deliberately redundant with the general "exactly maxLength" test from Part 1 (same
boundary, a different example string) — for a regression test specifically, duplicating
coverage of the exact failure mode is a feature, not a flaw: if someone later touches or
"cleans up" the general test for unrelated reasons, this one still stands guard
independently, explicitly labeled so a future reader immediately knows why it exists and
what reintroducing the bug would look like.

**Final verification:** full client suite re-run after the fix + regression test — 6
test files, 29 tests, all passing; `tsc --noEmit` and `eslint` both clean on the changed
files.
