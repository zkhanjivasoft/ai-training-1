# Review Findings — Writer-Reviewer Pattern

## Note on how the review was actually run

Task 1's file (`.claude/agents/reviewer.md`) was created and would be recognized by name
in a fresh Claude Code session. This conversation's Agent tool, however, had already
snapshotted its list of available subagent types at the start of the session, before the
file existed, so it did not pick up `reviewer` by name mid-session (confirmed by trying to
invoke `subagent_type: reviewer` directly and getting "Agent type 'reviewer' not found").
To still perform the review through an isolated agent rather than in this main session, I
spawned a `general-purpose` subagent and gave it the reviewer's full role/process/output
instructions verbatim as its persona, then handed it the same task the named subagent
would have received. The reviewing agent still had no visibility into this conversation —
it independently ran `git diff`, read the files fresh, and reported back with no memory of
why the change was written the way it was.

## The change under review ("writer" output)

A small, deliberately-uncommitted addition of `GET /notes/:id` to the `notes-api`
sub-project: `notesRepository.findById`, `notesService.getById`, and the route wiring in
`notes.routes.ts`.

## Findings from the reviewer + my agree/disagree notes

### Correctness — Critical — `findById`'s return type lies about `undefined`
The repository method is typed to return `Note` but `Array.find()` returns `Note |
undefined`, so `npm run typecheck` actually fails to compile.

**Agree.** I verified this myself by running `npm run typecheck` after the review came
back — it fails with exactly the error the reviewer quoted (`TS2322: Type 'Note |
undefined' is not assignable to type 'Note'`). This is the most valuable finding: a change
that doesn't even build, caught before it could be committed.

### Correctness — Major — `getById` silently returns `undefined` instead of signaling "not found"
Since the in-memory store starts empty, every `GET /notes/:id` call currently returns
`undefined`, and the route sends that as `res.json(undefined)` — a `200` with an empty
body, not a `404`. The reviewer also connected this to `notes-api/CLAUDE.md`'s own
documented convention that services throw on an expected failure like "note not found."

**Agree.** This is the real behavioral bug the type error was masking. It's a good example
of the reviewer doing more than a type-checker would: it explains *why* the wrong type
happened (an unhandled miss case) rather than just where.

### Naming & Readability — Nit — loose equality (`==`) instead of `===`
Flagged `n.id == id` in the repository.

**Agree, but rated correctly as a Nit.** Both sides are already typed `string`, so it's
not a real coercion hazard here — I appreciated that the reviewer said as much rather than
inflating the severity, and correctly noted there's no lint script yet to catch it
automatically.

### Error Handling — Major — no error-handling middleware exists to fulfill the documented contract
Pointed out that even after the service throws a "not found" error, nothing in `app.ts`
would translate that into a 404 — it would fall through to Express's default 500 handler.

**Partially disagree on severity, agree on substance.** The observation is accurate and
worth having on record, but I'd have filed it as **Minor** relative to *this* diff rather
than Major, since the reviewer itself acknowledged it "predates the diff" — the missing
middleware is pre-existing scaffold debt, not something this specific change introduced.
I'd still fix it in the same pass as the other two findings, just wouldn't block the PR on
it in isolation.

### Test Coverage — Major — no tests added, and no test tooling wired up at all
Correctly identified that `notes-api` has zero test files and no `vitest`/`supertest` in
`package.json`, despite `CLAUDE.md` documenting that convention.

**Agree it's a real gap, disagree it should gate this specific tiny diff.** Same reasoning
as the middleware finding: this is scaffold-wide debt (already flagged as a known gap in
the exercise-4 PR), not something introduced by adding one route. I'd track it as a
follow-up rather than block a one-endpoint change on standing up an entire test harness.

**Verdict given by the reviewer:** Request changes. I agree with that verdict — the
Critical + Major correctness findings alone are enough to hold this back, regardless of
how the two lower-priority findings should be weighted.

## Reflection: how context isolation affected review quality

Reviewing in a fresh, isolated context caught something I would very likely have missed
writing and reviewing in the same breath: I wrote `getById` intending "return the note or
undefined, the caller will sort it out later," and in the same mental frame as the writer,
that felt fine — I already knew what I meant. An isolated reviewer has no access to what I
meant, only to what the code and its type signature actually say, so the mismatch between
the claimed `Note` return type and the real `Note | undefined` behavior stood out
immediately as a build-breaking lie rather than a forgivable shorthand. The same is true
of the 404 gap: from the writer's seat, "I'll add the not-found handling later" is an
implicit plan that lives only in my head; the reviewer had no way to give me credit for an
intention it can't see, so it correctly treated the current code as complete and broken.
The one place isolation arguably overcorrected was severity on the two pre-existing-debt
findings — without the surrounding context of "this repo already tracks that gap
elsewhere," a fresh reviewer reasonably treats every gap it finds as urgent, which is why
a human still needs to sit above the report and weigh severity against project context
the reviewer doesn't have.
