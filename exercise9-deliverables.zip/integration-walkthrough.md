# Integration Walkthrough — Show, Specify, Verify

## The change

`server/src/services/stats.service.ts`, line 9: type `COMPLETED_STATUS` against the
shared `TodoStatus` union instead of a bare `string`, so a future typo in the literal
(e.g. `'Done'` or `'compelted'`) is a compile error rather than a silent runtime bug —
the exact class of bug the git-history commit `187550b` (found during orientation) had to
fix after the fact.

## Show

**Prompt:** "Read `server/src/services/stats.service.ts` in full and explain how it works,
especially the `COMPLETED_STATUS` constant and the `completedThisWeek` calculation."

**What was shown:**

```ts
import type { StatsSummary, TagStat } from '@taskboard/shared';
import { tagsRepository } from '../repositories/tags.repository';
import { todosRepository } from '../repositories/todos.repository';

function isoDateToday(): string {
  return new Date().toISOString().slice(0, 10);
}

const COMPLETED_STATUS: string = 'done';

export const statsService = {
  summary(): StatsSummary {
    const todos = todosRepository.findAll();
    const weekAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString();
    const today = isoDateToday();

    return {
      total: todos.length,
      open: todos.filter((t) => t.status === 'open').length,
      done: todos.filter((t) => t.status === 'done').length,
      byPriority: { /* ... */ },
      completedThisWeek: todos.filter(
        (t) => t.status === COMPLETED_STATUS && t.completedAt && t.completedAt >= weekAgo,
      ).length,
      overdue: todos.filter((t) => t.status === 'open' && t.dueDate && t.dueDate < today).length,
    };
  },
  byTag(): TagStat[] { /* ... */ },
};
```

`statsService.summary()` builds the dashboard's `StatsSummary` by running several
`.filter().length` passes over every todo. `COMPLETED_STATUS` exists specifically so the
`completedThisWeek` filter doesn't hardcode the literal `'done'` inline — but it's typed
as plain `string`, so TypeScript can't check that the value assigned to it is actually a
valid `TodoStatus`. This is the same constant that had to be corrected in commit `187550b`
after it was originally set to a status value (`'completed'`) that doesn't exist in the
`TodoStatus` union at all.

## Specify

**Prompt:** "In `stats.service.ts`, type `COMPLETED_STATUS` as `TodoStatus` (imported
type-only from `@taskboard/shared`, alongside the existing `StatsSummary`/`TagStat`
import) instead of `string`. Follow this project's conventions from `CLAUDE.md` and
`.claude/rules/backend.md`: import shared types with `import type` (never redeclare them
locally — the existing import line already does this correctly, just add `TodoStatus` to
it), and don't touch anything else in the file — this is a single, minimal type-tightening
change, not a refactor."

**What changed:**

```diff
- import type { StatsSummary, TagStat } from '@taskboard/shared';
+ import type { StatsSummary, TagStat, TodoStatus } from '@taskboard/shared';
  ...
- const COMPLETED_STATUS: string = 'done';
+ const COMPLETED_STATUS: TodoStatus = 'done';
```

Two lines. No behavior change for any currently-valid input — `'done'` is already a member
of `TodoStatus`, so this doesn't alter today's output at all. It only changes what the
compiler will accept the next time someone edits this line.

## Verify

**Prompt:** "Run `npm run typecheck -w server`, lint just this file, and run
`stats.service.test.ts` to confirm nothing broke."

**Results:**

1. `npm run typecheck -w server` → `tsc -p tsconfig.json` — passed, zero errors.
2. `npx eslint server/src/services/stats.service.ts` → zero output, zero errors/warnings.
3. `npx vitest run src/services/stats.service.test.ts` (from inside `server/`) → `1 test
   passed` (`counts a todo completed just now as completed this week`), the same test that
   was added alongside the original `COMPLETED_STATUS` fix in commit `187550b`.

All three checks passed cleanly — the change respects the project's existing conventions
(type-only import of a shared entity, per `BE-058`) and doesn't alter any currently
observable behavior, only tightens what future edits to this line are allowed to be.
