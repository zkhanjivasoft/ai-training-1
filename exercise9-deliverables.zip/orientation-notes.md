# Orientation Notes — server/ (TaskBoard backend)

This exercise's exploration targeted `server/` specifically, since earlier exercises in
this session mostly worked in the newer `notes-api` sub-project — `server/` is the part
of this repo I hadn't yet done a fresh, deliberate orientation pass on.

## Prompts used

- "List every `.ts` file under `server/src`, grouped by directory."
- "Show the last 20 commits with `git log --oneline -20`."
- "Show the full total commit count and the earliest commits (`git log --oneline --all | tail -20`)."
- "Show the full commit (`git show --stat`) for the bug-fix commit about weekly stats."
- "Diff the two near-identical 'count completed todos' commits against each other."
- "Read `server/src/services/stats.service.ts` in full."

## Project structure summary

`server/src` is a strict four-layer architecture, one file per layer per resource:

- `routes/` — thin HTTP layer (`<resource>.routes.ts` + a co-located `<resource>.routes.test.ts`)
- `services/` — business rules (`<resource>.service.ts` + `.test.ts`)
- `repositories/` — persistence only (`<resource>.repository.ts`, only `tags` has a test file)
- `schemas/` — zod request schemas, one per resource, separate from the service layer
- `lib/` — cross-cutting helpers: `errors.ts`, `ids.ts`, `logger.ts`, `respond.ts`, `validate.ts`
- `middleware/` — `errorHandler.ts`, `requestLogger.ts`
- `clients/` — one file, `inspirationClient.ts`, for the one external API this project calls
- `db/store.ts` — the sole module allowed to touch the JSON file on disk

Every resource (tags, todos, lists) repeats the same five files (schema, repository,
service + test, routes + test) — a deliberate, rigid vertical-slice pattern, not an
accident of one person's style.

## Patterns found in git history

`git log --oneline -20` mostly showed this training session's own exercise commits
(7 exercises deep at this point), so I looked past those to the 7 commits that predate
this training entirely. Two things stood out:

1. **Commit message discipline is inconsistent across the pre-training history itself.**
   Some commits are strict Conventional Commits with a real body and issue link —
   `fix: count completed todos as 'done' status in weekly stats (#7)`, body explaining
   *why* ("`completedThisWeek` filtered on a nonexistent `'completed'` status literal, so
   the count was always zero"), ending `Closes #1`. Others are terse, type-less labels:
   `Push docs folder`, `Add check convention file`, `Push Hypr chunk 1`. So the
   Conventional-Commits standard `CLAUDE.md` documents ("Conventional Commits; PRs link
   their issue with `Closes #N`") is a real, followed convention for at least one genuine
   bug-fix PR — but it coexists with earlier ad-hoc commits that don't follow it. This
   itself *is* the coexisting old/new pattern for Task 1's third prompt (see below).

2. **Two near-identical commits reveal the actual git workflow.** `965a8cd` and `187550b`
   have byte-identical diffs and messages, but different commit metadata: `965a8cd` is
   authored "Zaid Khan" with a plain Conventional Commits message; `187550b` is authored
   "zkhanjivasoft" (same email) with `(#7)` appended to the subject line — the exact
   signature GitHub's squash-merge leaves on a commit. So the real workflow is: commit
   locally with a disciplined Conventional Commits message → open a PR → GitHub
   squash-merges it onto `main`, appending `(#N)`. This matches what `CLAUDE.md` documents
   (`feat/<slug>` / `fix/<slug>` branches, PRs linking issues) — it's genuinely being
   followed, at least for that one fix.

## Coexisting old vs. new pattern

**The commit-message discipline split above is the clearest coexisting pattern I found**:
disciplined, Conventional-Commits-with-issue-link commits (one real bug-fix PR) sitting
in the same short history as informal, type-less commits (`Push docs folder`, `Add check
convention file`). Both are "old" in the sense that they all predate this training
session — it's not a chronological old-vs-new split, but a documented-standard-vs-actual-practice
split, which is arguably more useful to know before touching the codebase: the standard in
`CLAUDE.md` is real and was followed at least once, but isn't universally enforced in this
repo's own history, so I shouldn't assume every existing commit is a model to copy.

As a second, code-level example (not from git history): I noticed while orienting that
`server/src` uses **extensionless relative imports** (`import { z } from '../lib/validate'`,
documented as BE-061, required by `moduleResolution: bundler` + running via `tsx`), while
`notes-api` (a separate, newer sub-project built earlier in this same training) uses
**explicit `.js` extensions** on every relative import, required by its own
`moduleResolution: NodeNext`. These are two different, both-currently-correct import
conventions coexisting in the same monorepo, each valid only within its own sub-project's
`tsconfig.json` — a real trap for anyone copying an import style from one part of the repo
into the other.
