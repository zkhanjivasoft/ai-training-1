# Add a Feature to an Existing Project — Deliverables

**Project:** TaskBoard (this repo's main app: `server/`, `client/`, `shared/`).
**Feature:** Add activity/audit tracking for the "lists" resource — previously only
`todosService` mutations were recorded; `listsService.create/update/remove` had no
audit trail at all. Touches: `shared/src/types.ts`, 4 server files, 2 client files,
3 test files — genuinely crosses layers (route → service → repository → shared type).

## 1. Assessment summary

Ran a fresh codebase assessment (independent agent, no prior context on this feature)
targeting `server/` + `shared/`, with a specific question about `activity.service.ts`'s
exact current shape. Full findings in the agent's own words are in the session; the
load-bearing ones:

- One file per layer per resource (`routes/services/repositories/schemas`), named
  `<plural-resource>.<layer>.ts`, co-located `*.test.ts`.
- Services: object literals, synchronous, explicit return types, typed `AppError` throws
  (never null/undefined/tuples), own id/timestamp minting, log once per successful write.
- Repositories: pure persistence, synchronous, never throw (missing = `undefined`/`false`),
  fixed method vocabulary (`findAll`/`findById`/`insert`/`update`/`remove`/`findBy<Field>`).
- Routes: validate via `parseWith(schema, ...)`, call one service method, respond via
  `sendData`/`sendError` — no try/catch, Express 5 auto-forwards thrown errors.
- Tests: three layers, each scoped to its own concern (persistence / business-rules+error-class
  / HTTP-status+envelope); `makeTestDb()` in `beforeEach`, its `cleanup()` in `afterEach`.
- **Critical, specific finding:** `activityService.record(todo: Todo, action): ActivityEntry`
  is hard-typed to `Todo`, and `ActivityEntry` itself has `todoId`/`todoTitle` fields with
  no entity-kind discriminator anywhere — confirmed myself by reading the actual file
  rather than trusting the report, since this was the crux of the whole feature.

**Corrections I made to the assessment:** none needed — I independently verified the
single most important claim (the `Todo`-specific `record()` signature and the todo-named
`ActivityEntry` fields) against the actual source before trusting it, and it was accurate.
I did catch one thing the assessment correctly flagged as a hard blocker but which the
*build* phase later still got wrong in practice (see deviation log, item 1): the
assessment was right that this needed "new ground, not an extension of an existing
generic mechanism" — it just didn't (and couldn't, from static reading alone) predict
that the guarded seed data itself would still be in the old shape at runtime.

## 2. Rules list (8 concrete, checkable rules — exceeds the minimum of 5)

1. Mutating service methods start with `this.getById(id)` before any write (licenses the
   `repository.update(id, changes)!` non-null assertion).
2. Services signal expected failures by throwing typed `AppError` subclasses — never
   return null/undefined/tuples. No new error type for this feature.
3. Services own id minting (`newId('<prefix>')`) and timestamps (`new Date().toISOString()`)
   before calling the repository; repositories never do either.
4. Repositories are pure persistence: synchronous, never throw, fixed method vocabulary.
5. Only services log, via `logger.info('<file-basename>', msg, { id })`, after a
   successful write.
6. `ActivityEntry`'s `todoId`/`todoTitle` must be generalized to `entityType`/`entityId`/
   `entityTitle`, and `activityService.record()` to take those as parameters instead of a
   `Todo` object — cannot be bolted on by overloading the existing todo-shaped fields.
7. Service tests assert the thrown error class (`toThrow(NotFoundError)`); route tests
   assert status + the `{ data }`/`{ error: { code, message } }` envelope via `supertest`
   against `createApp()`, covering error paths as well as happy path.
8. A cross-tier shared-type change must migrate every real call site in the same change
   — no partial generalization (named the 8 confirmed call sites up front).

## 3. Deviation log

| # | Rule | What the generated code did instead | How it was fixed |
|---|------|--------------------------------------|-------------------|
| 1 | (Implicit extension of rule 6/8 — a gap the rules didn't explicitly anticipate) | The generalization was applied correctly everywhere in **code**, but `server/data/seed.json` (guarded, can never be edited) still has old-shape `todoId`/`todoTitle` activity rows with no `entityTitle`. After a real `npm run reset-db`, `ActivityFeed.tsx`'s `truncate(entry.entityTitle, 60)` would throw on `undefined`, crashing the Todos page render. Caught by the Phase 3 compliance reviewer, not by me or the builder during Phase 2 — I verified it myself afterward by actually running `reset-db` and curling the live server. | Added a `normalize()` read-time shim in `activity.repository.ts` (the only layer allowed to touch the store) that fills in `entityType: 'todo'`/`entityId`/`entityTitle` from the legacy fields when `entityType` is absent. Added `activity.repository.test.ts` covering it. Re-verified live against the real seed after `reset-db` — confirmed the legacy row now carries the new fields too. |
| 2 | Rule 7 (route tests must cover error paths) | The route's query contract changed (`todoId` → `entityId`) but no `activity.routes.test.ts` existed at all, and the old param name would now silently fall through unvalidated (zod strips unknown keys by default) rather than erroring. | Added `activity.routes.test.ts` (4 tests: happy path, `?entityId=` filter, `?limit=0` → 400, and the old `?todoId=` param → 400) and added `.strict()` to `activityQuerySchema` so an unrecognized query key is now a validation error instead of a silently-ignored one. |
| 3 | (Documentation consistency — not one of the 8 rules verbatim, but a real gap I found myself, separate from the Phase 3 reviewer) | `.claude/rules/backend.md`'s BE-010 still documented the *old* `activityService.record(entity, '<action>')` signature after the generalization — the codebase's own codified convention doc was left out of sync with the new reality. | Rewrote BE-010 to describe the generalized `record(entityType, entityId, entityTitle, action)` signature and note it now applies to any entity kind, not just todos; updated its example line to point at `lists.service.ts`. |
| 4 | Rule 7 (test assertions should be exact and robust) | The Phase 3 reviewer suggested tightening `lists.service.test.ts`'s delete-activity assertion from `.some(...)` to `feed[0]` for stricter checking. Applying that suggestion literally would have reintroduced a real flakiness risk: this specific test creates and deletes the *same* list back-to-back, so the `created`/`deleted` timestamps can tie at millisecond resolution, and `toSorted()`'s stability would then keep `created` first — unlike the analogous todos test, which deletes a pre-seeded fixture item with a fixed, much older timestamp, where `feed[0]` is safe. | Did not apply the suggestion as literally stated. Used `feed.find((e) => e.action === 'deleted')` instead — keeps the stronger assertion (checks `entityType`/`entityTitle`, not just presence) without depending on sort-order-under-ties, and left a comment explaining why this test specifically can't safely use `feed[0]` the way the todos test does. |

Every deviation above was resolved before the exercise's final state — items 1–3 are
fixed in the code/docs; item 4 is a case where I deliberately did **not** apply a
suggested fix as literally stated, with the reasoning documented.

## 4. Final compliance review

Ran via a fresh `pr-reviewer` subagent, given the 8 rules and told to check each
explicitly. Verdict: **Request changes** (before fixes) — found the 4 items in the
deviation log above (item 1 reported as Critical, item 2 as Major, item 3 was my own
independent catch not in its report, item 4's suggestion came from its Nit finding).
All 8 of the explicit rule checks came back COMPLY on their own terms; the review's real
value was the two things outside the literal 8-point checklist (the seed-data shape
mismatch, and the missing route test) plus one assertion-quality nit.

**My own notes on whether I agree:** I agree with the Critical and Major findings fully
— both were real, reproducible bugs (I independently confirmed the seed.json shape
myself with `grep`, and verified the fix live with a real `reset-db` + curl, not just by
re-running the test suite). I agree with the *spirit* of the Nit finding (the delete test
should assert more than "some entry somewhere has this action") but not with its literal
suggested implementation (`feed[0]`), for the timestamp-tie reason in deviation #4 above
— this is exactly the kind of "second pair of eyes, not a rubber stamp" moment the
exercise describes: useful feedback that still needed independent judgment before
applying it.

## 5. New pattern justification

**Yes, a new pattern was needed**, and it was decided deliberately in Phase 1 (rule 6),
not discovered by surprise mid-build: the existing `ActivityEntry` type and
`activityService.record()` signature were not a generic "record an activity for any
entity" mechanism that happened to only have one caller — they were genuinely
todo-specific by field name (`todoId`, `todoTitle`) and by parameter type (`Todo`), with
no discriminator field anywhere that a second entity kind could hook into. The existing
pattern could not cover a second resource without either (a) silently overloading
`todoId` to sometimes mean "list id" (a correctness/readability hazard baked permanently
into persisted data) or (b) a parallel, differently-shaped `ActivityEntry`-for-lists type
(duplicating the whole audit mechanism). Generalizing the one existing type/signature
with an explicit `entityType` discriminator was the smallest change that gives *any*
future third entity kind the same capability without another migration, which is the
genuine technical need — not a stylistic preference for a "nicer" shape.
