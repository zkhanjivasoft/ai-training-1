# Specification — newId(prefix)

**Function chosen:** `newId(prefix: string): string` in `server/src/lib/ids.ts`.

**Why this function:** It's untested (no `ids.test.ts` exists), it's used by every service in
the server (`BE-011`: "Services mint entity ids by calling `newId('<prefix>')`"), and it's
the single place `crypto.randomUUID()` is allowed to be called in `server/src` (`BE-067`) —
a small, self-contained pure-ish function (random but otherwise deterministic shape) that's
foundational enough that a bug in it would corrupt every entity id in the app.

**Important constraint I followed:** I have not opened `server/src/lib/ids.ts` in this
session. Everything below comes only from the documented contract in
`.claude/rules/backend.md`:
- BE-011: "Services mint entity ids by calling `newId('<prefix>')` ... producing e.g.
  `tag_9f2c1a7b`."
- BE-067: "`crypto.randomUUID()` is called only inside `lib/ids.ts`."

## Plain-language behavior

`newId(prefix)` returns a new unique identifier string, formed as `<prefix>_<8 hex chars>`.
The 8-character suffix is derived from a UUID (per BE-067), so it's lowercase hexadecimal
(`0-9a-f`) and effectively random/unique per call — I can't hand-calculate the *exact*
string a call will produce, but I *can* hand-calculate its exact shape, length, and
character set, which is the actual testable contract for an id generator.

## Hand-calculated expected input/output pairs

1. **`newId("tag")`** → a string matching `/^tag_[0-9a-f]{8}$/`, total length **12**
   (`"tag"` = 3 chars + `"_"` = 1 char + 8 hex chars = 12), because the documented example
   `tag_9f2c1a7b` is exactly that shape.
2. **`newId("todo")`** → a string matching `/^todo_[0-9a-f]{8}$/`, total length **13**
   (`"todo"` = 4 + `"_"` = 1 + 8 = 13) — same rule, different prefix, to confirm the
   function isn't hardcoded to `"tag"`.
3. **`newId("tag")` called twice** → the two results must be **different** from each other.
   Since the suffix comes from `crypto.randomUUID()` (122 bits of randomness in the
   relevant portion), the probability of an actual collision in a test run is negligible —
   this is a property test (uniqueness), not an exact-value test.

## Edge cases to add after the initial spec (per the taxonomy, added in Task 1 step 4)

- **Boundary/empty input:** `newId("")` — does an empty-string prefix produce `"_XXXXXXXX"`
  (length 9), or does the function reject/behave differently for a falsy-ish prefix?
- **Type coercion / unusual but valid input:** `newId("sub_task")` — a prefix that itself
  contains an underscore. Does the function just concatenate regardless (producing
  `"sub_task_XXXXXXXX"`), or does something in the implementation assume the prefix has no
  underscore (e.g. if it ever split on `_` to parse an id back apart)?

These weren't in my original 3 hand-calculated pairs — they were added afterward using the
edge-case taxonomy (boundary/empty input, and an "unusual but structurally valid" input),
per Task 1 step 4.
