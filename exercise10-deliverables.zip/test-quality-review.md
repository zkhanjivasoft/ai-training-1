# Test Quality Review — server/src/lib/ids.test.ts

## Test failures vs. code bugs

None. All 3 spec-derived tests passed on the first run against the real implementation
(`server/src/lib/ids.ts`), and reading the source afterward confirmed why: the actual
implementation is exactly `` `${prefix}_${crypto.randomUUID().slice(0, 8)}` ``, matching
the documented contract (BE-011/BE-067) I wrote the spec from, with no surprises. So this
round had neither a spec error nor a code bug to report — the spec-first approach was
simply confirmed correct. (Coverage tooling isn't installed in this workspace —
`@vitest/coverage-v8` is missing — so I ran the tests directly rather than under coverage,
noted here rather than silently skipped.)

## Quality review — approach

Delegated to a fresh, isolated subagent (the custom `reviewer` subagent from an earlier
exercise) with no context on why the tests were written, and asked it to focus
specifically on test quality (weak assertions, implementation coupling, missing
scenarios, flaky-test risk) rather than a general code review, since the tiny
implementation was already known-correct.

## Feedback received (summarized; full report is longer)

- **Weak assertion (the one I fixed — see below):** the uniqueness test compared only two
  calls (`expect(first).not.toBe(second)`), which is a near-vacuous guarantee — it would
  still pass even with a generator that had very little entropy. The reviewer proposed a
  bounded batch instead (n=200, ~4.6e-6 collision probability given the 32-bit suffix),
  large enough to actually test uniqueness, small enough to stay non-flaky.
- **Redundant assertions:** every `toHaveLength(...)` restates what its preceding anchored
  regex (`/^tag_[0-9a-f]{8}$/`) already implies — not wrong, but adds a second number to
  keep in sync with no new failure mode caught.
- **Implementation coupling:** the exact suffix shape (`[0-9a-f]{8}`) is repeated across
  4 different regexes; a valid refactor of the suffix source (longer slice, base36, etc.)
  would break every test even though the observable "unique per call" contract hasn't
  changed. Suggested hoisting it into one shared pattern/helper.
- **Duplicate coverage:** the `"tag"` and `"todo"` prefix tests exercise the same code
  path: suggested `it.each([...])`, which would also close a real gap — `list` and `act`
  (real prefixes used elsewhere in the codebase) are never exercised at all.
- **Missing scenarios:** nothing pins down the intended behavior for a prefix containing
  whitespace, `/`, `%`, or mixed case — the suite proves `newId` doesn't special-case
  `''` or an internal `_`, but never states whether unsanitized-prefix input is an
  accepted "garbage in, garbage out" contract or an unnoticed gap.
- **Flaky-test risk:** correctly assessed as low today (regex assertions hold for any
  valid UUID), but flagged that if someone later scales the uniqueness sample size up
  without understanding the 32-bit suffix, that would introduce real flakiness — worth a
  comment for the next author.

**Verdict given:** Approve with comments.

## What I changed, and why

Replaced the two-call uniqueness test with a 200-id batch-and-`Set`-size check:

```diff
- it('produces a different id on each call with the same prefix', () => {
-   const first = newId('tag');
-   const second = newId('tag');
-   expect(first).not.toBe(second);
- });
+ // The suffix is 8 hex chars (32 bits) sliced from a UUID, so collision probability
+ // is negligible at this sample size (~4.6e-6 for n=200) but would not be at, say,
+ // n=100,000 — keep this sample bounded rather than scaling it up.
+ it('produces 200 unique ids across 200 calls with the same prefix', () => {
+   const ids = Array.from({ length: 200 }, () => newId('tag'));
+   expect(new Set(ids).size).toBe(200);
+ });
```

I picked this specific fix over the others because it was the sharpest weak-assertion
finding (a two-sample uniqueness check is close to testing nothing) and because the
reviewer's own math justified exactly how large a sample stays safe from flakiness —
turning "trust me, it's random" into an actual, bounded, falsifiable check. I left the
other suggestions (hoisting the shared regex, `it.each` for prefixes, an explicit
unsanitized-prefix test) as follow-ups rather than applying all of them, since the
exercise asks for at least one specific, deliberate improvement rather than a full rewrite
— and I wanted the improvement I did make to be easy to verify in isolation (re-ran
`npx vitest run src/lib/ids.test.ts` after the change: still 5 tests, all passing).
