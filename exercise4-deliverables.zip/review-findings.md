# Review Findings — feat/notes-create

This review was run in a genuinely fresh context: a separate subagent with no
prior knowledge of this session or the code it wrote (spawned via the Agent
tool, `subagent_type: general-purpose`), not the same session that authored
the feature — matching the spirit of "use /clear before reviewing."

## Review prompt given to the fresh reviewer

> You are acting as a critical, independent code reviewer. You have NOT seen
> this code before and have no context on why it was written this way —
> review it cold, on its own merits.
>
> Repo: /Users/zaidkhan/Downloads/projects/ai-training-1
> Branch under review: feat/notes-create (currently checked out)
> Base: main
>
> First, read notes-api/README.md and notes-api/CLAUDE.md for context on what
> this sub-project is and what conventions it claims to follow. Then run
> `git diff main...HEAD -- notes-api` to see the actual changes.
>
> Evaluate the diff across AT LEAST these dimensions, explicitly labeled:
> 1. Correctness
> 2. Security
> 3. Error handling
> 4. Performance
> 5. Test coverage
> 6. Naming clarity
>
> For each dimension, either report a concrete finding (with file and line
> reference) or explicitly say "no issue found." Be genuinely critical.

**Dimensions evaluated:** Correctness, Security, Error handling, Performance,
Test coverage, Naming clarity (6 — exceeds the required 3).

## Claude's findings (summarized)

- **Correctness:** `notesService.create` assumed `title`/`body` were strings
  or `undefined`; a non-string value (e.g. `{"title": 123}`) or a literal
  `null` body would throw an uncaught `TypeError` instead of a clean
  validation error. Also flagged (low severity): 8-hex-char ids have a
  non-trivial collision chance at scale, with nothing to detect a collision.
- **Security:** The error middleware sent any thrown error's raw `.message`
  straight to the client, with no way to distinguish an intentional
  validation error from an unexpected internal exception.
- **Error handling (top finding):** `errorHandler` hardcoded every error to
  HTTP 400, contradicting the project's own `CLAUDE.md`, which documents that
  the middleware should map different failures to their correct status (e.g.
  404 for "not found"). No logging existed for unexpected errors either.
- **Performance:** No issue found — trivial in-memory operations at this scale.
- **Test coverage:** Zero tests exist anywhere in `notes-api/`, directly
  contradicting the Vitest/supertest convention already documented in
  `CLAUDE.md`. Listed the specific untested cases (boundary lengths,
  whitespace-only input, non-string input, middleware status/shape).
- **Naming clarity:** No issue found — names were consistent and clear.

## Follow-up question and response

**My follow-up:** "What's the smallest fix for the errorHandler — a
`statusCode` on a custom error class, message-sniffing, or something else?
And separately, is the missing `typeof` check severe enough to block merge on
its own, or fine to ship now and fix in a fast follow-up, given this is a
personal-scale scaffold?"

**Claude's response:** Recommended a small `HttpError(statusCode, message)`
class over message-sniffing (brittle, doesn't compose as more error cases
appear) — services throw `HttpError`, the middleware checks `instanceof
HttpError` for the right status and falls back to a logged generic 500
otherwise. On the `typeof` check, it pushed back on my "ship now, scaffold
project" framing directly: it argued the two issues compound — once the
errorHandler correctly falls back to 500 for non-`HttpError` exceptions, an
un-guarded non-string `title` would flip from "wrong 400" to "500 with a
logged stack trace" for what should be an ordinary validation failure — and
the fix is two lines reusing code already being touched in this PR, so there
was no real reason to defer it.

## Issue fixed before proceeding

Both points raised were legitimate and fixed in a follow-up commit
(`fix(notes-api): map errors to correct status codes, validate input types`)
before opening the PR:

- Added `lib/errors.ts` (`HttpError` class) and rewrote `errorHandler` to
  branch on `instanceof HttpError`, falling back to a logged 500 for
  anything else — including passing through body-parser's own status for
  malformed JSON bodies (a related edge case surfaced while re-testing).
- Added a `typeof input?.title !== 'string'` / `typeof input?.body !==
  'string'` guard at the top of `notesService.create`, throwing `HttpError(400,
  ...)` instead of letting a `TypeError` escape uncaught.

The missing test suite was intentionally **not** added in this PR — flagged
in the PR description as a known, scoped-out gap for a fast follow-up, per
the reviewer's own framing that it's a real gap but a separate unit of work
from the create-a-note feature itself.
