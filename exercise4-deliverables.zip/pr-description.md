# Pull Request

**URL:** https://github.com/zkhanjivasoft/ai-training-1/pull/8

## Title

feat(notes-api): add POST /notes to create a note

## Description

### Summary

Adds the first real feature to the `notes-api` scaffold: `POST /notes` to
create a note, replacing the placeholder-only scaffold from the previous
exercise. This is a small, deliberately scoped slice — list still just
returns everything, and there's no search/update/delete yet.

What changed:
- `notesService.create(input)` validates `title` (1-120 chars) and `body`
  (1-10,000 chars), trims whitespace, and rejects non-string input types.
- `notesRepository.insert()` appends the new note to the in-memory store.
- A new `lib/ids.ts` helper (`newId(prefix)`) generates ids as
  `note_<8 hex chars>`, per the convention already documented in
  `notes-api/CLAUDE.md`.
- A new `lib/errors.ts` exports `HttpError(statusCode, message)`, and
  `middleware/errorHandler.ts` maps it to the right response status, falls
  back to a logged 500 for anything unexpected, and passes through
  body-parser's own status for malformed JSON bodies.

Why the error-handling design changed mid-PR: a fresh-context review (a
separate agent with no prior knowledge of this code) flagged that the first
version of `errorHandler` hardcoded every thrown error to a 400 — including
genuine bugs — and leaked raw internal exception messages to the client. That
also didn't match the status-code-per-failure-type pattern this project's own
`CLAUDE.md` already documents. The `HttpError` class fixes that: only errors
a service deliberately throws as `HttpError` become 4xx responses with their
message; anything else becomes a generic, logged 500.

Known gap, called out by the same review and intentionally not fixed here to
keep this PR scoped: there are no automated tests yet for this logic
(`CLAUDE.md` documents Vitest + supertest as the intended approach). Adding
the Vitest/supertest setup is a natural next PR.

### Test plan

- [x] `npm run build` (tsc) succeeds with zero errors
- [x] `npm run typecheck` succeeds with zero errors
- [x] `npx eslint notes-api/src` is clean
- [x] Manually verified against the running compiled server (`node dist/index.js`):
  - `POST /notes` with a valid `{ title, body }` → `201` with the created note (id, timestamps present)
  - `POST /notes` with an empty title → `400` with a clear validation message
  - `POST /notes` with a non-string title (e.g. `123`) → `400` (not an uncaught `TypeError`)
  - `POST /notes` with a malformed JSON body (`null`) → `400` (not a `500`)
  - `GET /notes` after creating a note → returns the created note in the list
