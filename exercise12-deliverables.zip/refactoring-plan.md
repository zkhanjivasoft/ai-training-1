# Refactoring Plan — server/src/services/todos.service.ts

## File chosen

`server/src/services/todos.service.ts` (143 lines) — the largest service file in the
project, handling list/filter/paginate, CRUD, and status transitions for todos.

## Code smells identified (no changes made yet)

1. **`list()`, lines 46-53 — five near-identical imperative reassignment blocks.**
   ```ts
   if (query.status) todos = todos.filter((t) => t.status === query.status);
   if (query.priority) todos = todos.filter((t) => t.priority === query.priority);
   if (query.listId) todos = todos.filter((t) => t.listId === query.listId);
   if (query.tagId) todos = todos.filter((t) => t.tagIds.includes(query.tagId!));
   if (query.q) {
     const q = query.q;
     todos = todos.filter((t) => t.title.includes(q) || (t.notes ?? '').includes(q));
   }
   ```
   Five statements of the exact same shape (`if (query.X) todos = todos.filter(...)`),
   each reassigning the same `let todos` variable. It's not deeply nested (single level),
   but it's a textbook shotgun-repetition smell: adding a sixth filter means copy-pasting
   the pattern a sixth time, and the `q` case even needs an extra local variable just to
   satisfy TypeScript's narrowing across the reassignment. This block is also explicitly
   called out in `todos.service.test.ts`'s own header comment as untested: *"Filtering,
   search, and pagination in `todosService.list()` do not have tests yet."*

2. **`update()`, lines 95-103 — six near-identical conditional-spread expressions.**
   ```ts
   const changes: Partial<Todo> = {
     ...(input.title !== undefined && { title: input.title }),
     ...(input.notes !== undefined && { notes: input.notes ?? undefined }),
     ...(input.priority !== undefined && { priority: input.priority }),
     ...(input.listId !== undefined && { listId: input.listId }),
     ...(input.tagIds !== undefined && { tagIds: input.tagIds }),
     ...(input.dueDate !== undefined && { dueDate: input.dueDate ?? undefined }),
     updatedAt: new Date().toISOString(),
   };
   ```
   The `...(input.X !== undefined && { X: ... })` pattern is repeated six times with only
   the field name changing. A new optional field on `Todo` means repeating this exact
   five-token idiom a seventh time, with no compiler check that you got the guard right.

3. **`complete()` and `reopen()`, lines 110-135 — two near-duplicate method bodies.**
   Both follow the identical shape: `getById` → early-return if already in the target
   state → build timestamp(s) → `repository.update(...)` → `activityService.record(...)`
   → `logger.info(...)` → return. Only the target `status`, the `completedAt` handling,
   and the activity verb actually differ between the two ~12-line methods.

## Smell chosen: #1, the `list()` filter chain

**Why this one:** it's the most concrete and independently verifiable of the three — it's
the one the codebase's own tests already flag as a gap (the test file comment), so fixing
it forces the "write tests first" step to be genuine rather than a formality. It's also
the lowest-risk of the three to refactor safely: a pure, synchronous, side-effect-free
transformation (filter → sort → paginate) with a small, enumerable set of inputs (5
optional query params) that's easy to characterize completely with tests before touching
anything. #2 and #3 are real smells too, but are scoped to write up now and refactor in a
later pass, one at a time.

## Constraint carried into the plan

`.claude/rules/backend.md` documents rule **BE-019**: *"Filtering, sorting, and
pagination are in-memory service work over the whole collection from `findAll()`: chain
`.filter()` per query param, order with `.toSorted()`... Do not add query/sort/limit
parameters to repository methods."* So the refactor must keep the "one `.filter()` per
query param" shape — collapsing everything into a single combined predicate would fix
the duplication but introduce a different pattern than what this codebase has decided on
elsewhere. The fix is to keep five `.filter()` calls, chained, and remove only the
imperative `if (...) todos = todos.filter(...)` reassignment boilerplate around them.

## Step-by-step plan (before touching any code)

1. **Write tests first** for `todosService.list()`'s current filtering behavior — status,
   priority, listId, tagId, and the `q` text search — since none exist yet. Commit this
   separately as `test: add coverage for todosService.list() filtering`, before any
   refactor.
2. **Refactor**: replace the five `if (query.X) todos = todos.filter(...)` reassignment
   statements with a single fluent chain of five `.filter()` calls, each filter being a
   no-op pass-through when its corresponding query param is absent:
   ```ts
   let todos = todosRepository
     .findAll()
     .filter((t) => !query.status || t.status === query.status)
     .filter((t) => !query.priority || t.priority === query.priority)
     .filter((t) => !query.listId || t.listId === query.listId)
     .filter((t) => !query.tagId || t.tagIds.includes(query.tagId!))
     .filter((t) => !query.q || t.title.includes(query.q!) || (t.notes ?? '').includes(query.q!));
   ```
   Same number of `.filter()` calls (five, matching BE-019), same exact filtering
   behavior for every input, just declarative instead of imperative — no more repeated
   `if`/reassignment, and no more need for the extra `const q = query.q` local variable
   just to satisfy narrowing.
3. **Run the test suite** (`npx vitest run` from `server/`) and confirm all tests —
   the new ones and the 58 pre-existing ones — still pass.
4. **Commit the refactor separately**, with a `refactor:` prefix, e.g.
   `refactor: replace todosService.list() filter reassignments with a filter chain`.
5. Capture `git log --oneline -5` to show the test commit and the refactor commit as two
   distinct entries.

Only this one smell is addressed in this pass — smells #2 and #3 are documented above as
candidates for a future, separate refactoring pass, not touched here.
