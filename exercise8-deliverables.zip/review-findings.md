# Review Findings — searchNotes

## The generated function

`notes-api/src/lib/search.ts`:

```ts
import type { Note } from '../types.js';

/** Case-insensitive substring search over a note's title and body. */
export function searchNotes(notes: Note[], query: string): Note[] {
  const q = query.toLowerCase();
  return notes.filter(
    (note) => note.title.toLowerCase().includes(q) || note.body.toLowerCase().includes(q),
  );
}
```

A case-insensitive substring search over notes' `title`/`body`, matching the search
capability `notes-api/README.md` already documents as planned but not yet implemented.
Not yet wired into any route.

## Layer 1 — Automated review

**Tools used:** `npm run typecheck`, `npm run build` (both `tsc`), and `npx eslint
notes-api/src/lib/search.ts` against the repo's root ESLint config.

**Findings:** All three passed cleanly with zero errors or warnings. No test suite exists
for `notes-api` yet (`package.json` has no `test` script, no `vitest` dependency), so there
was nothing to run at this layer beyond typecheck/build/lint.

**Would issues below have been caught here?** No — every finding from layers 2 and 3 is a
logic or contract issue (what happens on an empty query, what happens on non-string input,
missing tests), none of which a type checker or linter can detect. This layer only proves
the code is syntactically and structurally valid, not that it behaves correctly.

## Layer 2 — Manual review (by me)

1. **Correctness edge case:** an empty-string query (`''`) matches every note, since
   `''.includes('')` is always `true` — arguably reasonable as "no filter," but undocumented
   in the one-line JSDoc.
2. **Correctness edge case:** the query isn't trimmed — `"  overdue  "` won't match a note
   containing `"overdue"` without the padding.
3. **Type-safety boundary risk:** the signature requires `query: string`, but Express's
   `req.query.q` is typed `string | ParsedQs | string[] | undefined`. Not a live bug since
   nothing calls this yet, but a real risk once wired into a route.
4. **Pattern consistency:** matches the project's conventions (named export, one-line
   JSDoc, synchronous). The one structural note: it's the first file under `src/lib/` on
   `main` — not yet reflected in `README.md`'s documented structure.

**Would issues below have been caught here?** I caught the empty-query and type-boundary
issues myself, but the fresh review (layer 3) found a *sharper* version of both — it
specifically pinpointed that `''` and `' '` (whitespace) produce *opposite* results (all
notes vs. no notes), which I hadn't isolated as precisely, and it caught a concrete Express
5 repro (`GET /notes?q=a&q=b` → an array, not a string) that I hadn't thought through. I
also completely missed the diacritics/Unicode edge case and the missing-test-file gap being
compounded by the workspace having no test runner installed at all.

## Layer 3 — AI-assisted review, in a fresh isolated context

**Approach:** Delegated to a separate subagent (the custom `reviewer` subagent built in an
earlier exercise) with zero knowledge of this conversation — it independently read the file,
`types.ts`, the routes/services/repository files, `README.md`, `CLAUDE.md`, and
`package.json` before reporting.

**Findings (summarized, full detail in the subagent's report):**
- **Major (Correctness):** `''` returns every note, `' '` (whitespace) returns none —
  opposite behavior for adjacent inputs, neither documented.
- **Minor (Correctness):** `toLowerCase()` doesn't fold diacritics/Unicode — `"Café"` isn't
  found by querying `"cafe"`.
- **Minor (Security):** no bound on query length or corpus size — CPU/allocation
  amplification risk at scale (not a ReDoS, since no regex is used).
- **Major (Error Handling):** a non-string `query` (e.g. Express parsing `?q=a&q=b` as an
  array) throws an uncaught `TypeError` that would surface as an unintended 500.
- **Major (Test Coverage):** no test file exists, and the workspace has no test runner
  installed at all, so the documented Vitest convention can't even run here.
- **Out of scope, flagged without severity:** a stale `dist/lib/` containing compiled
  `errors.js`/`ids.js` with no matching `src/lib/` source (worth confirming `dist/` is
  gitignored and just stale); `search.ts` lands ahead of the "no feature code yet" statement
  in `notes-api/CLAUDE.md`, worth confirming that's the intended next step;
  `notesRepository.findAll()` returns the store array by reference, which `searchNotes` is
  safe against (it copies via `filter`) but a future consumer might not be.
- **Verdict:** Request changes.

**Would the manual-review issues have been caught here?** Yes, and more precisely — the
fresh reviewer had no memory of my intent for the function (I never told it my reasoning
about the empty-query default), so it treated the `''`/`' '` asymmetry purely as an
unexplained contract gap rather than a plausible design choice, and it independently
verified there were zero existing callers via `grep`, something I hadn't checked.

## Overall

Automated checks caught nothing (the code is valid, just not fully correct). Manual review
caught real issues but less precisely than the isolated AI review, which found two things I
missed entirely (Unicode folding, query-length bound) and sharpened two things I'd already
noticed. None of layers 1–3 alone would have surfaced the full picture — the value was in
running all three.
