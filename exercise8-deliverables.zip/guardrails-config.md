# Guardrails Configuration

## .claude/settings.json — permissions

```json
{
  "permissions": {
    "allow": ["Bash(npm run typecheck:*)", "Bash(npm test:*)"],
    "deny": [
      "Edit(server/data/seed.json)",
      "Write(server/data/seed.json)",
      "Bash(git push --force:*)",
      "Bash(rm -rf:*)"
    ]
  }
}
```

(The full file also keeps this repo's existing `hooks` config — a `PreToolUse`/
`PostToolUse` pair that runs `protect-seed.js` and `check-convention.js` on every
`Edit`/`Write` — unchanged.)

**Allow rules:**
- `Bash(npm run typecheck:*)` — run constantly during any TypeScript change across three
  workspaces; read-only and side-effect-free, so there's no reason to prompt for it every time.
- `Bash(npm test:*)` — same reasoning: run after nearly every change to verify nothing broke,
  never mutates anything on its own.

**Deny rules:**
- `Edit(server/data/seed.json)` / `Write(server/data/seed.json)` — already existed before
  this exercise; kept as-is (see reasoning below, shared with the CLAUDE.md guardrail).
- `Bash(git push --force:*)` — new. This repo has one shared `main` branch that every
  exercise and CI build depends on; a force-push can silently discard someone else's
  already-pushed commits with no easy recovery once the remote is overwritten.
- `Bash(rm -rf:*)` — new. An unrecoverable bulk delete, where a narrower, reversible
  action (`git checkout --`, `git clean -n` to preview, or just moving a file aside) almost
  always achieves the same cleanup without the risk of deleting something unintended.

## CLAUDE.md — Guardrails section

```markdown
## Guardrails

- **Never force-push to `main`** (enforced by a deny rule in `.claude/settings.json`:
  `Bash(git push --force:*)`). Reasoning: `main` is the shared branch every exercise and CI
  build depends on; a force-push can silently discard commits someone else already pushed,
  with no easy recovery once it's overwritten on the remote.
- **Never run `rm -rf`** (enforced by a deny rule in `.claude/settings.json`:
  `Bash(rm -rf:*)`). Reasoning: it's an unrecoverable bulk delete. A narrower, reversible
  action — `git checkout --` to discard tracked changes, `git clean -n` to preview untracked
  files before removing them, or simply moving a file aside — achieves the same cleanup
  without the risk of deleting something that was never meant to go.
- **Never modify `server/data/seed.json`** (see Do/Don't above; also enforced by a deny
  rule and a PreToolUse hook). Reasoning: it's the canonical baseline every lab resets to
  via `npm run reset-db` — a bad edit here corrupts every exercise's starting state, not
  just the current session's.
```

This was appended to the existing root `CLAUDE.md` (added as a new section right before
the `@AGENTS.md` import at the end of the file), not written to a separate draft — it's now
live, persistent project context.
