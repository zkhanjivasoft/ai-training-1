# Skill File — .claude/skills/check-changes/SKILL.md

```markdown
---
name: check-changes
description: Reviews staged (or unstaged) local changes for correctness bugs, security issues, and naming/readability problems before a commit. Use when asked to "check my changes", "review before I commit", or run "/check-changes" — not a general code review of the whole codebase, only of the current git diff.
context: fork
---

# Review the current diff

Current staged diff:

!`git diff --staged`

If that's empty, review the unstaged diff instead:

!`git diff`

Review the diff shown above across at least these three categories:

1. **Correctness** — does the change do what it appears to intend? Trace any changed
   condition, loop bound, or comparison against concrete inputs; flag anything that would
   produce a wrong result for a plausible input.
2. **Security** — unvalidated input reaching a sink (a shell command, a query, a log
   line, an HTTP response), secrets or internal detail leaking outward, missing bounds
   checks.
3. **Naming & readability** — do new or renamed identifiers say what they are without
   requiring the reader to open the implementation? Flag only what actually costs a
   reader time, not a style preference.

For each issue found, report:
- **File:** the path
- **Line:** the line number in the new version of the file
- **Severity:** Critical / Major / Minor / Nit
- **Suggested fix:** the minimal change, described or as a short snippet

If the diff is empty in both the staged and unstaged case, say so plainly and stop —
don't invent findings against files that aren't part of the current change.
```

## How it was tested

Created a deliberately flawed scratch file (`notes-api/src/lib/scratch-test.ts`):

```ts
export function x(a: string): string {
  return a.slice(0, a.length);
}
```

Staged it (`git add`), then invoked the skill directly (the equivalent of `/check-changes`).
The `!`git diff --staged`` injection correctly pulled in the staged diff, and the skill
returned real findings across categories, not a rubber-stamp:

- **Naming (Minor):** flagged `x` and `a` as giving the reader zero information about
  purpose, with a concrete rename suggestion.
- **Correctness/dead-code (Nit):** caught that `a.slice(0, a.length)` is a no-op identical
  to just returning `a`, and separately noted the file looked like leftover exploratory
  code that probably shouldn't be committed.
- **Security:** correctly reported none, since there's no external input or sink involved
  — it didn't force a finding just to fill the category.

The scratch file was then unstaged and deleted — it existed only to test the skill.
