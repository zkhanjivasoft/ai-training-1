# Hook and Settings

## .claude/hooks/edit-reminder.sh

```bash
#!/bin/bash
# Read the JSON event data from stdin (unused beyond this — we just need to drain it).
event_json="$(cat)"

echo "Reminder: run /check-changes before committing"
exit 0
```

Made executable with `chmod +x .claude/hooks/edit-reminder.sh`.

## Relevant hooks block from .claude/settings.json

```json
{
  "hooks": {
    "PostToolUse": [
      {
        "matcher": "Edit|Write",
        "hooks": [
          {
            "type": "command",
            "command": "node \"$CLAUDE_PROJECT_DIR/.claude/hooks/check-convention.js\""
          },
          {
            "type": "command",
            "command": "bash \"$CLAUDE_PROJECT_DIR/.claude/hooks/edit-reminder.sh\""
          }
        ]
      }
    ]
  }
}
```

Appended to the existing `PostToolUse` → `Edit|Write` matcher (already used by this
repo's `check-convention.js`) rather than replacing it — both hooks now run on every
`Edit`/`Write`.

## Test result and a real finding

Two things were checked:

1. **The script's own mechanics, in isolation** — piped a sample PostToolUse JSON payload
   into the script directly: it read stdin, printed
   `Reminder: run /check-changes before committing` to stdout, and exited 0. Confirmed
   correct.
2. **Whether the reminder surfaced after a real `Edit` tool call in this session** — it
   did not appear as a message to me. Reading this repo's own `check-convention.js`
   (already registered on the same `PostToolUse` event) explains why: its header comment
   documents that "any event + exit 0 → allow, say nothing [to Claude]" — only
   `stderr` + `exit 2` on `PostToolUse` reaches Claude as a nudge; plain `stdout` + `exit 0`
   is exactly what the exercise asked for (a **non-blocking** reminder), but that output
   is what a human running Claude Code interactively would see printed in their own
   terminal after the edit, not something fed back into my context. I don't have a way to
   observe my own terminal-facing stdout from inside this session, the same limitation
   noted for `/context`/`/clear` in an earlier exercise.

So: the reminder message did **not** visibly appear to me during the test, but that's the
expected, correct behavior for an `exit 0` PostToolUse hook per this repo's own documented
hook contract — not a sign the hook is broken. It would appear in a human developer's
terminal in an interactive session. If literal visual confirmation is required for
grading, that's the one part of this exercise that needs a human to actually watch their
own terminal after triggering an edit in an interactive session.
