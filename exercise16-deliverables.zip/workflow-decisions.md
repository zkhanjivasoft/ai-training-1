# Workflow Decision Matrix

1. **You are on a train with your phone and want to check on a Claude Code session
   running on your office desktop.**
   **Feature: Remote Control.** You need to view/interact with a session that's already
   running on a *different, specific machine* (your office desktop) from a *different*
   device (your phone) — Remote Control exists exactly for supervising or steering a live
   session on hardware you're not physically at.

2. **You started a conversation on claude.ai/code from your tablet and now want to
   continue it in your local terminal with access to your files and environment.**
   **Feature: Teleport.** The key requirement is moving a cloud-only session down into an
   environment with real local file-system and environment access — that's specifically
   what Teleport does: it hands a cloud conversation off to your local terminal.

3. **You are monitoring a staging deployment and want Claude to check the health
   endpoint every 5 minutes while you work on something else in the same session.**
   **Feature: /loop.** This is scoped to *the current session* and needs a short,
   session-lifetime recurring check (not a durable schedule that must survive the session
   ending) — `/loop` is exactly a session-scoped repeating task.

4. **You want Claude to run a code quality report every morning at 9 AM, even when your
   laptop is closed.**
   **Feature: Cloud scheduled task.** "Even when your laptop is closed" is the
   determining detail — the task must run independent of any local machine's power state,
   which only a cloud-hosted schedule can guarantee.

5. **You are at dinner and want to send a task to your Desktop app at home to start
   working on a bug fix.**
   **Feature: Dispatch.** You're not present at the machine and just want to *kick off* a
   task on a specific, already-available app instance (your home Desktop) right now,
   fire-and-forget — that's Dispatch, not a recurring schedule and not live remote control.

6. **You need to run the same refactoring task across three repositories simultaneously
   without blocking your terminal.**
   **Feature: Desktop scheduled task.** You want several local, repo-scoped jobs to run
   in the background via the Desktop app without tying up your interactive terminal —
   scheduling them (even as near-immediate one-offs) through the Desktop app is what lets
   three run in parallel while your terminal stays free for other work.
