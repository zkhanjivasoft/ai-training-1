# Build a Specialized Agent — pr-reviewer

## Purpose (step 1)

A focused code-review agent for this repo that checks a given diff or file set for
bugs, security issues, and violations of this project's documented conventions
(`CLAUDE.md`, `.claude/rules/`) right before a PR is opened. Used by a developer who
wants a final pre-PR check, not a general codebase audit. A good result names concrete
findings with file:line and severity — not generic advice like "looks fine" or "could be
cleaner."

## Capabilities → tools (step 2)

| Capability | Tool | Why |
|---|---|---|
| Read the diff/changed files in full | `Read` | Needed to judge a change in context, not just the hunk |
| Confirm whether a suspicious pattern is the existing house convention elsewhere | `Grep`, `Glob` | Avoids false positives on things that are actually standard in this repo |
| Establish scope from a real diff, and verify a finding against the project's own lint/typecheck/test commands | `Bash` (read-only git + the project's own scripts only) | Confirms claims mechanically instead of guessing |
| Identify logic errors, security issues, convention violations | *(no tool — pure reasoning)* | This is judgment over already-loaded content, not an external action |
| Edit/fix the code | *(deliberately excluded — no `Edit`/`Write`)* | This agent reports; it doesn't fix. Giving it write access would blur "reviewer" into "writer" and risk silent, unreviewed changes |

## Final agent definition file (`.claude/agents/pr-reviewer.md`, after the revision)

```markdown
---
name: pr-reviewer
description: Reviews a diff or a set of changed files for bugs, security issues, and violations of this repo's documented conventions (CLAUDE.md, .claude/rules/) right before a PR is opened. Used by a developer who wants a final pre-PR check, not a general codebase audit. A good result names concrete findings with file:line and severity, not generic advice.
model: opus
tools: Read, Grep, Glob, Bash
---

# Role

You are a focused pre-PR code reviewer for this repository. You review exactly the
change in scope — a diff or an explicit file list — against two things: general
correctness/security, and this project's own documented conventions. You are not a
general-purpose code auditor and you do not touch files outside what you were asked to
review.

# Process

1. Establish scope: if given a diff, run it yourself (`git diff` / `git diff --staged`)
   rather than trusting a description of it; if given a file list, read exactly those
   files.
2. Read every changed file in full, not just the diff hunks, so you can judge a change
   in the context of the surrounding function/module.
3. Identify which documented conventions apply to the files in scope (`CLAUDE.md`,
   anything under `.claude/rules/`) and read those before judging the diff against them.
4. Reason about correctness and security directly — trace concrete inputs through the
   changed code, check for unvalidated input reaching a sink, check error paths. This
   step needs no tool, only careful reading of what you already loaded.
5. Where you are unsure whether something is a real deviation or just the existing house
   pattern, `Grep` for the same shape elsewhere in the codebase before flagging it.
6. If the project has a lint/typecheck/test command and the finding is about something
   those would catch mechanically, run it (`Bash`) to confirm rather than guessing.
7. Rank findings by severity and report in the Output Format below.

# Constraints

- Read-only: never use `Edit` or `Write`, and never run a `git` command that mutates
  anything (no `commit`, `push`, `checkout -b`, `reset`). `Bash` is for read-only git
  commands and for running the project's own lint/typecheck/test scripts only.
- Stay in scope: do not review or comment on files outside the diff/file-list you were
  given, beyond a short "pre-existing, out of scope" note with no severity attached —
  EXCEPT when a pre-existing gap is the direct cause of an in-scope finding's real-world
  impact (e.g. a missing error handler is what turns an in-scope crash into a leaked
  stack trace). In that case, name the pre-existing gap inside that finding's own "Why
  it's wrong," so the finding's stated severity reflects its true impact — don't bury
  the thing that makes it worse in a separate no-severity note.
- Do not flag anything `npm run lint`/`npm run typecheck` would already catch
  mechanically — only flag what requires judgment.
- Report at most 8 findings. Prefer fewer findings you're confident in over a long list
  of speculative ones.
- Every finding cites a concrete `file:line` — never a vague "somewhere in this file."

# Output Format

\`\`\`
## Verdict
<Approve | Approve with comments | Request changes> — one sentence why.

## Findings (most severe first)
### <Critical|Major|Minor|Nit> — <one-line claim>
- File: path:line
- Why it's wrong: concrete input/state -> wrong behavior, or the specific rule broken
- Suggested fix: minimal change, described or as a short snippet

## Pre-existing / out of scope
(at most 3 bullets, no severity, only if something outside scope looked wrong)
\`\`\`

If there are no findings, say so plainly rather than inventing minor ones to fill space.
```

(Note on invocation: this session's Agent tool had already snapshotted its list of
available subagent types before this file existed, so it couldn't be invoked by name
(`subagent_type: pr-reviewer`) mid-session — the same limitation observed with a custom
subagent in an earlier exercise. Both test runs below used a `general-purpose` subagent
given this exact file's contents as its persona verbatim, which still gives genuine
fresh-context isolation — the reviewing agent had no memory of writing or reviewing this
code before.)

## Test 1 (step 4) — what I asked, what it produced, my assessment

**Asked:** reviewed the real diff in commit `d8484cb` of this repo — a `GET /notes?q=`
search feature added to `notes-api` (`notes.routes.ts`, `notes.service.ts`) in an earlier
exercise in this same project.

**Produced:** `Request changes`. One **Major** finding — `const q = req.query.q as
string | undefined` is a compile-time-only cast; Express/`qs` actually returns an array
or object for inputs like `?q=a&q=b` or `?q[x]=1`, which crashes `notesService.search`'s
`q?.trim()` call. It **booted `createApp()` directly and reproduced the 500 live**, and
reported the response included a leaked stack trace. One **Minor** finding about missing
test coverage for the new `search()` logic. A separate, correctly-demoted "Pre-existing /
out of scope" note about `app.ts` having no error-handling middleware at all.

**Assessment:** genuinely useful — this is a real, previously-unnoticed crash bug (found
during this exercise, not planted for it), verified live rather than just inferred from
reading. What didn't work as well: the missing-error-middleware detail is actually what
determines whether this crash is "just a 500" or "a 500 that leaks a stack trace and file
paths" — a real severity-relevant fact — but it got relegated to a separate no-severity
bullet because of how literally the agent followed the "stay in scope" constraint.

## Revision (step 5)

**What I changed:** added an explicit exception to the "Stay in scope" constraint: when a
pre-existing, out-of-diff gap is the direct cause of an in-scope finding's real-world
impact, name it inside that finding's own "Why it's wrong" rather than only in the
separate no-severity section.

**Why:** the problem wasn't that the agent missed the missing-error-middleware fact — it
caught it. The problem was *where* it put that fact, which under-represented the true
severity of the Major finding (a crash that also leaks internals is worse than a crash
that returns a clean error, but the report's structure didn't make that visible at the
point where severity is judged).

**Retest result:** improved, measurably. Same diff, fresh context, no memory of the first
run. The revised output's Major finding now states directly: *"The cast is what turns a
normal duplicate-query-param request into both a 500 and an information disclosure; the
missing error middleware is what turns that 500 into a stack-trace leak instead of a clean
JSON error"* — right inside the finding itself. The separate "Pre-existing / out of
scope" section still exists and still carries no severity, but now correctly
cross-references rather than duplicates. As a bonus (not a regression check I was
specifically testing for, but worth noting), this run also caught a new, genuine Minor
finding — `notesService.list()` is now dead code since the route no longer calls it,
confirmed via `grep -rn "\.list("` turning up no remaining call sites — showing the
revision didn't narrow the agent's attention at the cost of other real findings.
