# Prompting and Iterating — working notes (task: implement notes-api's `?q=` search)

## Two-minute rule

- **What I know:** `notes-api/README.md` documents `GET /notes?q=<text>` as a planned
  endpoint ("optionally `?q=<text>` to search title/body"), but `notes.routes.ts` and
  `notes.service.ts` currently ignore query params entirely — `list()` just returns
  everything. `notes-api/CLAUDE.md` establishes that business logic belongs in the
  service, not the route, and that services are object literals with synchronous,
  named-export methods.
- **What I'm unsure of:** whether an absent/empty `q` should return every note (no
  filter) or none, and whether the match needs to be case-insensitive on both `title`
  and `body`, or just one of them.
- **What "good" looks like:** a case-insensitive substring match across both `title`
  and `body`, implemented inside `notesService` (not inline in the route), with an
  absent/empty `q` explicitly falling back to "return everything" rather than an
  accidental edge case.

## Initial RTCE prompt (verbatim, as submitted)

> **Role:** You're a backend engineer working on this specific project, following its
> existing conventions exactly as documented in `notes-api/CLAUDE.md`.
>
> **Task:** Implement the `GET /notes?q=<text>` search that `notes-api/README.md`
> already documents as planned but is not yet built. Wire it into the existing
> `GET /notes` route — don't add a new route.
>
> **Context:** The current route (`notes-api/src/routes/notes.routes.ts`) and service
> (`notes-api/src/services/notes.service.ts`) ignore all query params; `list()` just
> returns every note. Match this project's conventions: the route only reads
> `req.query.q` and passes it to the service — the service owns the actual filtering
> logic, not the route. There's no test runner installed in `notes-api` yet, so don't
> add test files for this.
>
> **Expectations:** The search must be a case-insensitive substring match against BOTH
> `title` and `body` — a note matches if the query appears in either field, regardless
> of case. If `q` is absent or an empty string, return every note unfiltered (don't
> treat empty-string as "no results"). Only touch `notes.routes.ts` and
> `notes.service.ts` — no new files, no new dependencies. Show me the full updated
> contents of both files.

**Specificity test applied before sending:** the first draft of this prompt just said
"add search to GET /notes" — that alone could produce ten different reasonable
outputs (route-level vs. service-level filtering, case-sensitive vs. not, title-only
vs. title+body, empty-query-means-nothing vs. empty-query-means-everything, a brand
new endpoint instead of a query param). I tightened it by pinning down exactly those
five decision points before submitting.

## First response (what the AI produced)

```ts
notesRouter.get('/', (req, res) => {
  const q = req.query.q as string | undefined;
  const notes = notesService.list();
  if (q) {
    res.json(notes.filter((n) => n.title.toLowerCase().includes(q.toLowerCase()) || n.body.includes(q)));
    return;
  }
  res.json(notes);
});
```

`notes.service.ts` was left untouched.

## Critical read of the first response

- **Right:** an absent/empty `q` correctly falls through to `res.json(notes)` (all
  notes, unfiltered) — matches the "empty means everything" requirement exactly.
- **Missing/incorrect:** the `body` side of the filter — `n.body.includes(q)` — has no
  `.toLowerCase()` on either side, while the `title` side does. Verified concretely: a
  query of `"HELLO"` against a body containing `"hello"` returns `false` with the
  current code, `true` with the fix (`body.toLowerCase().includes(q.toLowerCase())`) —
  confirmed by direct comparison. This breaks the explicit "case-insensitive... against
  BOTH title and body" requirement for one of the two fields.
- **Incorrect relative to context, not just a style nit:** all of the filtering logic
  landed inline in the route handler. The prompt's Context section said explicitly "the
  service owns the actual filtering logic, not the route" — `notes.service.ts` wasn't
  touched at all, so this doesn't just read awkwardly, it contradicts an instruction
  that was given.

## Follow-up feedback prompt (verbatim, as submitted)

> Two things to fix, in priority order:
>
> **[critical]** The body-field match isn't case-insensitive — only `title` gets
> `.toLowerCase()` on both sides; `body` compares `n.body.includes(q)` with no
> lowercasing at all. I confirmed this breaks the explicit requirement: querying
> `"HELLO"` against a body containing `"hello"` currently returns no match. Apply the
> same `.toLowerCase()` treatment to the `body` side that `title` already gets.
>
> **[important]** The filtering logic needs to move into `notesService`, not stay
> inline in the route — I said this explicitly in the Context: "the service owns the
> actual filtering logic, not the route." Add a method on `notesService` (e.g.
> `search(q)` or extend `list()` to accept an optional query) that does the
> title/body matching, and have the route just call it with `req.query.q` and nothing
> else.
>
> **[nice-to-have]** The query isn't trimmed — `"  hello  "` (with padding) won't match
> a body containing `"hello"` without the whitespace. Not a stated requirement, but
> worth a `.trim()` on `q` before using it, since query strings from a real client can
> easily pick up stray whitespace.

## Revised response

```ts
// notes.routes.ts
notesRouter.get('/', (req, res) => {
  const q = req.query.q as string | undefined;
  res.json(notesService.search(q));
});

// notes.service.ts
search(q: string | undefined): Note[] {
  const notes = notesRepository.findAll();
  const query = q?.trim().toLowerCase();
  if (!query) return notes;
  return notes.filter(
    (n) => n.title.toLowerCase().includes(query) || n.body.toLowerCase().includes(query),
  );
},
```

Verified directly (not just read): `tsc` build is clean, `eslint` on both files is clean,
and the exact case-sensitivity repro from the critical finding now resolves correctly
(`"HELLO"` matches a body containing `"hello"`).

## Comparison against step 1's definition of "good"

- Case-insensitive match across both `title` and `body` — **yes**, both sides of both
  comparisons now lowercase.
- Filtering logic lives in `notesService`, not the route — **yes**, the route is now a
  single pass-through line.
- Absent/empty `q` returns every note — **yes**, and trimming now also makes
  whitespace-only `q` (e.g. `"   "`) fall into the same "return everything" path.

All three criteria from my original definition of "good" are met — no second iteration
was needed.

## Reflection

Next time I'd put the "logic belongs in the service, not the route" instruction in the
**Expectations** section instead of burying it inside **Context**, since that's exactly
the one requirement the first response ignored — not because it misunderstood it, but
because a structural/architectural constraint read more like background information
than a concrete deliverable requirement at the point in the prompt where I placed it.
